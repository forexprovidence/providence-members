import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export default function Calculator() {
  const [strategyId, setStrategyId] = useState<number>(1);
  const [initialDeposit, setInitialDeposit] = useState(10000);
  const [monthlyContribution, setMonthlyContribution] = useState(1000);
  const [period, setPeriod] = useState<"6m" | "1y">("6m");

  const { data: strategies } = trpc.strategies.list.useQuery();
  const { data: monthlyResults } = trpc.strategies.getMonthlyResults.useQuery(
    { strategyId },
    { enabled: strategyId !== null }
  );
  const { data: cdiData } = trpc.strategies.getCdiData.useQuery();

  const selectedStrategy = strategies?.find((s) => s.id === strategyId);

  // Calcular simulação
  const simulationData = useMemo(() => {
    if (!monthlyResults || monthlyResults.length === 0) return [];

    const months = period === "6m" ? monthlyResults.slice(-6) : monthlyResults;
    const data = [];
    let providenceBalance = initialDeposit;
    let cdiBalance = initialDeposit;

    for (let i = 0; i < months.length; i++) {
      const month = months[i];
      const cdi = cdiData?.find((c) => c.month === month.month);

      // Calcular retorno Providence
      const providenceReturn = month.profitPercentage / 100 / 100; // Converter para decimal
      providenceBalance = providenceBalance * (1 + providenceReturn) + monthlyContribution;

      // Calcular retorno CDI
      const cdiReturn = (cdi?.monthlyRate || 0) / 100 / 100; // Converter para decimal
      cdiBalance = cdiBalance * (1 + cdiReturn) + monthlyContribution;

      data.push({
        month: month.month,
        providence: Math.round(providenceBalance),
        cdi: Math.round(cdiBalance),
        difference: Math.round(providenceBalance - cdiBalance),
      });
    }

    return data;
  }, [monthlyResults, cdiData, initialDeposit, monthlyContribution, period]);

  const finalData = simulationData[simulationData.length - 1];
  const totalContributed = initialDeposit + monthlyContribution * simulationData.length;
  const providenceGain = finalData ? finalData.providence - totalContributed : 0;
  const cdiGain = finalData ? finalData.cdi - totalContributed : 0;
  const advantage = finalData ? finalData.difference : 0;

  return (
    <div className="container py-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Calculadora de Aportes</h1>
        <p className="text-muted-foreground">Simule o crescimento do seu investimento</p>
      </div>

      {/* Configurações */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-6">Parâmetros de Simulação</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Estratégia */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Estratégia</label>
            <select
              value={strategyId}
              onChange={(e) => setStrategyId(parseInt(e.target.value))}
              className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
            >
              {strategies?.map((strategy) => (
                <option key={strategy.id} value={strategy.id}>
                  {strategy.name}
                </option>
              ))}
            </select>
          </div>

          {/* Período */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Período</label>
            <div className="flex gap-2">
              <button
                onClick={() => setPeriod("6m")}
                className={`flex-1 px-4 py-2 rounded border transition-colors ${
                  period === "6m"
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border text-foreground hover:border-primary"
                }`}
              >
                6 Meses
              </button>
              <button
                onClick={() => setPeriod("1y")}
                className={`flex-1 px-4 py-2 rounded border transition-colors ${
                  period === "1y"
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-border text-foreground hover:border-primary"
                }`}
              >
                1 Ano
              </button>
            </div>
          </div>

          {/* Depósito Inicial */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Depósito Inicial (USD)</label>
            <input
              type="number"
              value={initialDeposit}
              onChange={(e) => setInitialDeposit(parseFloat(e.target.value))}
              className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
              min="0"
            />
          </div>

          {/* Aporte Mensal */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Aporte Mensal (USD)</label>
            <input
              type="number"
              value={monthlyContribution}
              onChange={(e) => setMonthlyContribution(parseFloat(e.target.value))}
              className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
              min="0"
            />
          </div>
        </div>
      </Card>

      {/* Resultados */}
      {finalData && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 border border-border bg-card">
            <p className="text-muted-foreground text-sm mb-2">Saldo com {selectedStrategy?.name}</p>
            <p className="text-3xl font-bold text-primary">${finalData.providence.toLocaleString("en-US")}</p>
            <p className="text-sm text-success mt-2">+${providenceGain.toLocaleString("en-US")}</p>
          </Card>

          <Card className="p-6 border border-border bg-card">
            <p className="text-muted-foreground text-sm mb-2">Saldo com CDI</p>
            <p className="text-3xl font-bold text-accent">${finalData.cdi.toLocaleString("en-US")}</p>
            <p className="text-sm text-success mt-2">+${cdiGain.toLocaleString("en-US")}</p>
          </Card>

          <Card className="p-6 border border-border bg-card">
            <p className="text-muted-foreground text-sm mb-2">Diferença com {selectedStrategy?.name}</p>
            <p className={`text-3xl font-bold ${advantage >= 0 ? "text-success" : "text-destructive"}`}>
              {advantage >= 0 ? "+" : "-"}${Math.abs(advantage).toLocaleString("en-US")}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              {advantage > 0 ? "+" : ""}{((advantage / finalData.cdi) * 100).toFixed(2)}%
            </p>
          </Card>
        </div>
      )}

      {/* Gráfico */}
      {simulationData.length > 0 && (
        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Evolução do Investimento</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={simulationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted-foreground)" />
              <YAxis stroke="var(--muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: `1px solid var(--border)`,
                  borderRadius: "0.5rem",
                  color: "var(--foreground)",
                }}
                formatter={(value) => `$${(value as number).toLocaleString("en-US")}`}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="providence"
                stroke="var(--primary)"
                strokeWidth={2}
                name={selectedStrategy?.name || "Providence"}
                dot={{ fill: "var(--primary)" }}
              />
              <Line
                type="monotone"
                dataKey="cdi"
                stroke="var(--accent)"
                strokeWidth={2}
                name="CDI"
                dot={{ fill: "var(--accent)" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Tabela Detalhada */}
      {simulationData.length > 0 && (
        <Card className="p-6 border border-border bg-card overflow-x-auto">
          <h3 className="text-lg font-semibold text-foreground mb-4">Dados Mês a Mês</h3>
          <table className="w-full text-sm">
            <thead className="border-b border-border">
              <tr>
                <th className="text-left py-2 px-4 text-muted-foreground font-semibold">Mês</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">{selectedStrategy?.name}</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">CDI</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">Diferença</th>
              </tr>
            </thead>
            <tbody>
              {simulationData.map((row, idx) => (
                <tr key={idx} className="border-b border-border hover:bg-secondary/50">
                  <td className="py-3 px-4 text-foreground">{row.month}</td>
                  <td className="text-right py-3 px-4 text-primary font-semibold">
                    ${row.providence.toLocaleString("en-US")}
                  </td>
                  <td className="text-right py-3 px-4 text-accent font-semibold">
                    ${row.cdi.toLocaleString("en-US")}
                  </td>
                  <td className="text-right py-3 px-4 text-success font-semibold">
                    ${row.difference.toLocaleString("en-US")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {/* Empty State */}
      {simulationData.length === 0 && (
        <Card className="p-8 text-center border border-border bg-card">
          <p className="text-muted-foreground">Nenhum dado disponível para simulação</p>
        </Card>
      )}
    </div>
  );
}
