import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Mail, Lock } from "lucide-react";

export default function Login() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const utils = trpc.useUtils();
  const loginMutation = trpc.users.login.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.email || !formData.password) {
      toast.error("Preencha todos os campos");
      return;
    }

    try {
      console.log("[Login] Submitting login form");
      const result = await loginMutation.mutateAsync({
        email: formData.email,
        password: formData.password,
      });
      console.log("[Login] Login successful, result:", result);

      toast.success("Login realizado com sucesso!");
      
      // Refrescar auth.me para pegar o usuário autenticado
      console.log("[Login] Refreshing auth.me query");
      await utils.auth.me.refetch();
      console.log("[Login] Auth.me refreshed");
      
      // Aguardar um pouco e redirecionar
      setTimeout(() => {
        console.log("[Login] Redirecting to dashboard");
        navigate("/dashboard");
      }, 500);
    } catch (error: any) {
      toast.error(error?.message || "Erro ao fazer login");
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Navigation */}
      <nav className="bg-card border-b border-border sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">P</span>
            </div>
            <span className="font-bold text-foreground text-lg">Providence</span>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="border-primary text-primary hover:bg-primary/10"
          >
            Voltar
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="flex-1 container py-12 flex items-center justify-center">
        <Card className="w-full max-w-md p-8 border border-border bg-card">
          <h1 className="text-3xl font-bold text-foreground mb-2">Login</h1>
          <p className="text-muted-foreground mb-8">Acesse sua conta com email e senha</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="seu@email.com"
                />
              </div>
            </div>

            {/* Senha */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Sua senha"
                />
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-2"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "Entrando..." : "Entrar"}
            </Button>
          </form>

          {/* Signup Link */}
          <p className="text-center text-muted-foreground mt-6">
            Ainda não tem uma conta?{" "}
            <button
              onClick={() => navigate("/signup")}
              className="text-primary hover:underline font-medium"
            >
              Cadastre-se
            </button>
          </p>
        </Card>
      </div>
    </div>
  );
}
