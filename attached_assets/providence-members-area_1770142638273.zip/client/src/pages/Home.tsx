import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { TrendingUp, BarChart3, Calculator, Shield } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // Redirecionar para dashboard se autenticado
  useEffect(() => {
    if (isAuthenticated && !loading) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground">Carregando...</div>
      </div>
    );
  }

  if (isAuthenticated) {
    return null; // Redirecionando para dashboard
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Navigation */}
      <nav className="bg-card border-b border-border sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">P</span>
            </div>
            <span className="font-bold text-foreground text-lg">Providence</span>
          </div>
          <a href="/login">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              Fazer Login
            </Button>
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="flex-1 container py-20 space-y-8">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground">
            Bem-vindo à Área de Membros
          </h1>
          <p className="text-xl text-muted-foreground">
            Acompanhe em tempo real os resultados das estratégias de investimento da Providence Forex
          </p>
          <div className="flex gap-4 justify-center pt-4 flex-wrap">
            <a href="/login">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                Fazer Login
              </Button>
            </a>
            <a href="/signup">
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10">
                Ainda não é membro? Cadastre-se
              </Button>
            </a>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-12">
          {/* Dashboard */}
          <Card className="p-6 border border-border bg-card hover:border-primary transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Dashboard</h3>
              <p className="text-sm text-muted-foreground">
                Cadastre e visualize os dados das suas estratégias para melhor visualização
              </p>
            </div>
          </Card>

          {/* Resultados */}
          <Card className="p-6 border border-border bg-card hover:border-primary transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Resultados</h3>
              <p className="text-sm text-muted-foreground">
                Acompanhe gráficos comparativos com CDI e histórico detalhado
              </p>
            </div>
          </Card>

          {/* Calculadora */}
          <Card className="p-6 border border-border bg-card hover:border-primary transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Calculator className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Calculadora</h3>
              <p className="text-sm text-muted-foreground">
                Simule o crescimento dos seus aportes com projeções realistas
              </p>
            </div>
          </Card>

          {/* Segurança */}
          <Card className="p-6 border border-border bg-card hover:border-primary transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Segurança</h3>
              <p className="text-sm text-muted-foreground">
                Autenticação OAuth segura com controle de acesso por perfil
              </p>
            </div>
          </Card>
        </div>

        {/* Estratégias */}
        <div className="pt-12 space-y-6">
          <h2 className="text-3xl font-bold text-foreground text-center">Nossas Estratégias</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Ultimate */}
            <Card className="p-8 border border-border bg-card space-y-4">
              <h3 className="text-2xl font-bold text-primary">Projeto Ultimate</h3>
              <p className="text-muted-foreground">
                Estratégia conservadora focada em rentabilidade consistente e baixo risco
              </p>
              <div className="space-y-2 pt-4 border-t border-border">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Depósito Mínimo</span>
                  <span className="font-semibold text-foreground">$200</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Comissão</span>
                  <span className="font-semibold text-foreground">20%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Risco</span>
                  <span className="font-semibold text-success">Baixo</span>
                </div>
              </div>
            </Card>

            {/* Alavancado */}
            <Card className="p-8 border border-border bg-card space-y-4">
              <h3 className="text-2xl font-bold text-accent">Projeto Alavancado</h3>
              <p className="text-muted-foreground">
                Estratégia agressiva com potencial de retornos maiores e risco moderado
              </p>
              <div className="space-y-2 pt-4 border-t border-border">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Depósito Mínimo</span>
                  <span className="font-semibold text-foreground">$200</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Comissão</span>
                  <span className="font-semibold text-foreground">20%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Risco</span>
                  <span className="font-semibold text-warning">Moderado</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <div className="pt-12 text-center space-y-6 bg-card border border-border rounded-lg p-8">
          <h2 className="text-3xl font-bold text-foreground">Pronto para começar?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Faça login na sua conta para acessar o dashboard completo, acompanhar resultados em tempo real e usar a calculadora de aportes
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Acessar Agora
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-12">
        <div className="container py-8 text-center text-muted-foreground text-sm">
          <p>&copy; 2025 Providence Forex. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
