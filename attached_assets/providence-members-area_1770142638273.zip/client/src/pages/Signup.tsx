import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Mail, Lock, User, Smartphone } from "lucide-react";

export default function Signup() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    roboForexAccount: "",
  });

  const signupMutation = trpc.users.signup.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.name || !formData.email || !formData.password || !formData.roboForexAccount) {
      toast.error("Preencha todos os campos");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error("As senhas não conferem");
      return;
    }

    if (formData.password.length < 8) {
      toast.error("A senha deve ter pelo menos 8 caracteres");
      return;
    }

    if (!/^\d+$/.test(formData.roboForexAccount)) {
      toast.error("Número de conta deve conter apenas números");
      return;
    }

    try {
      await signupMutation.mutateAsync({
        name: formData.name,
        email: formData.email,
        password: formData.password,
        roboForexAccount: formData.roboForexAccount,
      });

      toast.success("Cadastro realizado com sucesso! Redirecionando para login...");
      setTimeout(() => navigate("/"), 2000);
    } catch (error: any) {
      const errorMessage = error?.data?.code === 'BAD_REQUEST' 
        ? error?.data?.zodError?.[0]?.message || error?.message
        : error?.message || "Erro ao realizar cadastro";
      toast.error(errorMessage);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Navigation */}
      <nav className="bg-card border-b border-border sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">P</span>
            </div>
            <span className="font-bold text-foreground text-lg">Providence</span>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="border-primary text-primary hover:bg-primary/10"
          >
            Voltar
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="flex-1 container py-12 flex items-center justify-center">
        <Card className="w-full max-w-md p-8 border border-border bg-card">
          <h1 className="text-3xl font-bold text-foreground mb-2">Cadastro</h1>
          <p className="text-muted-foreground mb-8">Crie sua conta para acessar a área de membros</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Nome */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Nome Completo</label>
              <div className="relative">
                <User className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Seu nome"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="seu@email.com"
                />
              </div>
            </div>

            {/* Número de Conta RoboForex */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Número de Conta RoboForex</label>
              <div className="relative">
                <Smartphone className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={formData.roboForexAccount}
                  onChange={(e) => setFormData({ ...formData, roboForexAccount: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Apenas números"
                />
              </div>
            </div>

            {/* Senha */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Mínimo 8 caracteres"
                />
              </div>
            </div>

            {/* Confirmar Senha */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Confirmar Senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
                <input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Confirme sua senha"
                />
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-2"
              disabled={signupMutation.isPending}
            >
              {signupMutation.isPending ? "Cadastrando..." : "Cadastrar"}
            </Button>
          </form>

          {/* Login Link */}
          <p className="text-center text-muted-foreground mt-6">
            Já tem uma conta?{" "}
            <button
              onClick={() => navigate("/")}
              className="text-primary hover:underline font-medium"
            >
              Faça login
            </button>
          </p>
        </Card>
      </div>
    </div>
  );
}
