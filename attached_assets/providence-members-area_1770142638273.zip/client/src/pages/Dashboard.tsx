import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Edit2, Trash2, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Dashboard() {
  const { user } = useAuth({ redirectOnUnauthenticated: true, redirectPath: "/login" });
  const { data: strategies, isLoading: strategiesLoading } = trpc.strategies.list.useQuery();
  const { data: roboAccounts, isLoading: accountsLoading, refetch: refetchAccounts } = trpc.users.getRoboForexAccounts.useQuery();
  const createAccountMutation = trpc.users.createRoboForexAccount.useMutation();
  const deleteAccountMutation = trpc.users.deleteRoboForexAccount.useMutation();

  const [showForm, setShowForm] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    accountNumber: "",
    platform: "mt4" as "mt4" | "mt5",
    depositedAmount: 200,
    depositDate: new Date().toISOString().split('T')[0],
  });

  const handleCreateAccount = async (strategyId: number) => {
    if (!formData.accountNumber || !formData.platform || formData.depositedAmount < 200) {
      toast.error("Preencha todos os campos corretamente");
      return;
    }

    if (!/^\d+$/.test(formData.accountNumber)) {
      toast.error("Número de conta deve conter apenas números");
      return;
    }

    try {
      await createAccountMutation.mutateAsync({
        strategyId,
        accountNumber: formData.accountNumber,
        platform: formData.platform,
        depositedAmount: formData.depositedAmount,
        depositDate: formData.depositDate,
      });
      toast.success("Conta criada com sucesso!");
      setShowForm(null);
      setFormData({ accountNumber: "", platform: "mt4", depositedAmount: 200, depositDate: new Date().toISOString().split('T')[0] });
      refetchAccounts();
    } catch (error) {
      toast.error("Erro ao criar conta");
    }
  };

  const handleDeleteAccount = async (accountId: number) => {
    if (!confirm("Tem certeza que deseja deletar esta conta?")) return;

    try {
      await deleteAccountMutation.mutateAsync(accountId);
      toast.success("Conta deletada com sucesso!");
      refetchAccounts();
    } catch (error) {
      toast.error("Erro ao deletar conta");
    }
  };

  if (strategiesLoading || accountsLoading) {
    return <div className="container py-8">Carregando...</div>;
  }

  const getAccountsForStrategy = (strategyId: number) => {
    return roboAccounts?.filter((acc) => acc.strategyId === strategyId) || [];
  };

  return (
    <div className="container py-8">
      <h1 className="text-4xl font-bold text-foreground mb-2">Dashboard</h1>
      <p className="text-muted-foreground mb-8">Bem-vindo, {user?.name}</p>

      <h2 className="text-2xl font-bold text-foreground mb-6">Suas Estratégias</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {strategies?.map((strategy) => {
          const accounts = getAccountsForStrategy(strategy.id);

          return (
            <Card key={strategy.id} className="p-6 border border-border bg-card">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-foreground">{strategy.name}</h3>
                  <p className="text-sm text-muted-foreground">{strategy.description}</p>
                </div>
                <span className={`px-3 py-1 rounded text-sm font-medium ${strategy.riskLevel === "conservative" ? "bg-green-900/30 text-green-400" : "bg-green-900/30 text-green-400"}`}>
                  {strategy.riskLevel === "conservative" ? "Conservador" : "Agressivo"}
                </span>
              </div>

              {accounts.length === 0 ? (
                <div className="mb-4">
                  <p className="text-muted-foreground mb-4">Você ainda não possui uma conta nesta estratégia</p>
                  <Button
                    onClick={() => setShowForm(strategy.id)}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    Cadastrar Conta
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 mb-4">
                  {accounts.map((account) => (
                    <div key={account.id} className="p-4 bg-input rounded border border-border">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-sm text-muted-foreground">Conta: <span className="text-foreground font-medium">{account.accountNumber}</span></p>
                          <p className="text-sm text-muted-foreground">Plataforma: <span className="text-foreground font-medium">{account.platform.toUpperCase()}</span></p>
                          <p className="text-sm text-muted-foreground">Data de Depósito: <span className="text-foreground font-medium">{new Date(account.depositDate).toLocaleDateString('pt-BR')}</span></p>
                          <p className="text-sm text-muted-foreground">Saldo Atual: <span className="text-foreground font-medium">${account.depositedAmount}</span></p>
                          <p className="text-sm text-muted-foreground">Lucro Total: <span className={`font-medium ${0 >= 0 ? "text-green-400" : "text-red-400"}`}>$0 (0.00%)</span></p>
                          <p className="text-sm text-muted-foreground">Drawdown Máximo: <span className="text-foreground font-medium">0.00%</span></p>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 hover:bg-background rounded transition">
                            <Edit2 className="w-4 h-4 text-muted-foreground" />
                          </button>
                          <button onClick={() => handleDeleteAccount(account.id)} className="p-2 hover:bg-background rounded transition">
                            <Trash2 className="w-4 h-4 text-red-400" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button
                    onClick={() => setShowForm(strategy.id)}
                    variant="outline"
                    className="w-full border-primary text-primary hover:bg-primary/10"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar Outra Conta
                  </Button>
                </div>
              )}

              {showForm === strategy.id && (
                <div className="p-4 bg-input rounded border border-border space-y-3">
                  <div>
                    <label className="text-sm text-muted-foreground">Número de Conta (apenas números)</label>
                    <input
                      type="text"
                      value={formData.accountNumber}
                      onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                      className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="123456"
                    />
                  </div>

                  <div>
                    <label className="text-sm text-muted-foreground">Plataforma</label>
                    <select
                      value={formData.platform}
                      onChange={(e) => setFormData({ ...formData, platform: e.target.value as "mt4" | "mt5" })}
                      className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="mt4">MT4</option>
                      <option value="mt5">MT5</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm text-muted-foreground">Valor Depositado (USD)</label>
                    <input
                      type="number"
                      value={formData.depositedAmount}
                      onChange={(e) => setFormData({ ...formData, depositedAmount: Number(e.target.value) })}
                      className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="200"
                      min="200"
                    />
                  </div>

                  <div>
                    <label className="text-sm text-muted-foreground">Data de Depósito</label>
                    <input
                      type="date"
                      value={formData.depositDate}
                      onChange={(e) => setFormData({ ...formData, depositDate: e.target.value })}
                      className="w-full mt-1 px-3 py-2 bg-background border border-border rounded text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleCreateAccount(strategy.id)}
                      className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                      disabled={createAccountMutation.isPending}
                    >
                      {createAccountMutation.isPending ? "Criando..." : "Criar Conta"}
                    </Button>
                    <Button
                      onClick={() => setShowForm(null)}
                      variant="outline"
                      className="flex-1 border-border text-foreground hover:bg-input"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-border mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Depósito Mínimo</p>
                    <p className="text-lg font-bold text-foreground">${strategy.minimumDeposit}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Comissão</p>
                    <p className="text-lg font-bold text-foreground">{strategy.commissionPercentage}%</p>
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
