import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export default function Results() {
  const [selectedStrategy, setSelectedStrategy] = useState<number | null>(null);
  const [period, setPeriod] = useState<"6m" | "1y">("6m");

  const { data: strategies, isLoading: strategiesLoading } = trpc.strategies.list.useQuery();
  const { data: monthlyResults } = trpc.strategies.getMonthlyResults.useQuery(
    { strategyId: selectedStrategy || 0 },
    { enabled: selectedStrategy !== null }
  );
  const { data: cdiData } = trpc.strategies.getCdiData.useQuery();

  if (strategiesLoading) {
    return (
      <div className="container py-8">
        <div className="text-foreground">Carregando dados...</div>
      </div>
    );
  }

  // Preparar dados para o gráfico
  const chartData = monthlyResults?.map((result) => ({
    month: result.month,
    providence: (result.finalBalance / result.initialBalance - 1) * 100,
    initialBalance: result.initialBalance,
    finalBalance: result.finalBalance,
  })) || [];

  // Adicionar dados do CDI
  const chartDataWithCdi = chartData.map((item) => {
    const cdi = cdiData?.find((c) => c.month === item.month);
    return {
      ...item,
      cdi: cdi ? cdi.accumulatedRate / 100 : 0,
    };
  });

  // Filtrar por período
  const filteredData =
    period === "6m"
      ? chartDataWithCdi.slice(-6)
      : chartDataWithCdi;

  return (
    <div className="container py-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Resultados</h1>
        <p className="text-muted-foreground">Acompanhe a performance das estratégias</p>
      </div>

      {/* Seleção de Estratégia */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-4">Selecione uma Estratégia</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {strategies?.map((strategy) => (
            <button
              key={strategy.id}
              onClick={() => setSelectedStrategy(strategy.id)}
              className={`p-4 rounded border-2 transition-colors text-left ${
                selectedStrategy === strategy.id
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50"
              }`}
            >
              <h4 className="font-semibold text-foreground">{strategy.name}</h4>
              <p className="text-sm text-muted-foreground mt-1">{strategy.description}</p>
            </button>
          ))}
        </div>
      </Card>

      {/* Período */}
      {selectedStrategy && (
        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Período</h3>
          <div className="flex gap-4">
            <Button
              onClick={() => setPeriod("6m")}
              className={`${
                period === "6m"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/90"
              }`}
            >
              Últimos 6 Meses
            </Button>
            <Button
              onClick={() => setPeriod("1y")}
              className={`${
                period === "1y"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/90"
              }`}
            >
              Último Ano
            </Button>
          </div>
        </Card>
      )}

      {/* Gráfico */}
      {selectedStrategy && chartDataWithCdi.length > 0 && (
        <Card className="p-6 border border-border bg-card">
          <h3 className="text-lg font-semibold text-foreground mb-4">Performance Comparativa</h3>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted-foreground)" />
              <YAxis stroke="var(--muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: `1px solid var(--border)`,
                  borderRadius: "0.5rem",
                  color: "var(--foreground)",
                }}
                formatter={(value) => `${(value as number).toFixed(2)}%`}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="providence"
                stroke="var(--primary)"
                strokeWidth={2}
                name={strategies?.find((s) => s.id === selectedStrategy)?.name || "Providence"}
                dot={{ fill: "var(--primary)" }}
              />
              <Line
                type="monotone"
                dataKey="cdi"
                stroke="var(--accent)"
                strokeWidth={2}
                name="CDI"
                dot={{ fill: "var(--accent)" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Tabela de Dados */}
      {selectedStrategy && monthlyResults && monthlyResults.length > 0 && (
        <Card className="p-6 border border-border bg-card overflow-x-auto">
          <h3 className="text-lg font-semibold text-foreground mb-4">Dados Detalhados</h3>
          <table className="w-full text-sm">
            <thead className="border-b border-border">
              <tr>
                <th className="text-left py-2 px-4 text-muted-foreground font-semibold">Mês</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">Saldo Inicial</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">Saldo Final</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">Lucro/Prejuízo</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">Rentabilidade</th>
                <th className="text-right py-2 px-4 text-muted-foreground font-semibold">Drawdown Máx</th>
              </tr>
            </thead>
            <tbody>
              {(period === "6m" ? monthlyResults.slice(-6) : monthlyResults).map((result) => (
                <tr key={result.id} className="border-b border-border hover:bg-secondary/50">
                  <td className="py-3 px-4 text-foreground">{result.month}</td>
                  <td className="text-right py-3 px-4 text-foreground">
                    ${result.initialBalance.toLocaleString("en-US")}
                  </td>
                  <td className="text-right py-3 px-4 text-foreground">
                    ${result.finalBalance.toLocaleString("en-US")}
                  </td>
                  <td
                    className={`text-right py-3 px-4 font-semibold ${
                      result.profitLoss >= 0 ? "text-success" : "text-destructive"
                    }`}
                  >
                    ${result.profitLoss.toLocaleString("en-US")}
                  </td>
                  <td
                    className={`text-right py-3 px-4 font-semibold ${
                      result.profitPercentage >= 0 ? "text-success" : "text-destructive"
                    }`}
                  >
                    {(result.profitPercentage / 100).toFixed(2)}%
                  </td>
                  <td className="text-right py-3 px-4 text-warning">
                    {(result.maxDrawdown / 100).toFixed(2)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {/* Empty State */}
      {selectedStrategy && (!monthlyResults || monthlyResults.length === 0) && (
        <Card className="p-8 text-center border border-border bg-card">
          <p className="text-muted-foreground">Nenhum dado disponível para esta estratégia</p>
        </Card>
      )}
    </div>
  );
}
