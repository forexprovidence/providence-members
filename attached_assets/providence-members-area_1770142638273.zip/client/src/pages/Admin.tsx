import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Trash2, Edit2 } from "lucide-react";
import { useState } from "react";

function UsersTab() {
  const { data: allUsers, isLoading } = trpc.users.listAll.useQuery();
  const deleteUserMutation = trpc.users.delete.useMutation();
  const updateRoleMutation = trpc.users.updateRole.useMutation();

  const handleDeleteUser = async (userId: number) => {
    if (!confirm("Tem certeza que deseja deletar este usuário?")) return;
    try {
      await deleteUserMutation.mutateAsync(userId);
      toast.success("Usuário deletado com sucesso!");
    } catch (error) {
      toast.error("Erro ao deletar usuário");
    }
  };

  const handleChangeRole = async (userId: number, newRole: "user" | "admin") => {
    try {
      await updateRoleMutation.mutateAsync({ userId, role: newRole });
      toast.success("Role atualizado com sucesso!");
    } catch (error) {
      toast.error("Erro ao atualizar role");
    }
  };

  if (isLoading) {
    return <div className="text-foreground">Carregando usuários...</div>;
  }

  const totalUsers = allUsers?.length || 0;
  const adminCount = allUsers?.filter((u) => u.role === "admin").length || 0;
  const userCount = totalUsers - adminCount;

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="p-4 border border-border bg-card/50">
          <p className="text-muted-foreground text-sm mb-2">Total de Usuários</p>
          <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
        </Card>
        <Card className="p-4 border border-border bg-card/50">
          <p className="text-muted-foreground text-sm mb-2">Usuários Comuns</p>
          <p className="text-2xl font-bold text-foreground">{userCount}</p>
        </Card>
        <Card className="p-4 border border-border bg-card/50">
          <p className="text-muted-foreground text-sm mb-2">Administradores</p>
          <p className="text-2xl font-bold text-primary">{adminCount}</p>
        </Card>
      </div>

      <Card className="p-6 border border-border bg-card overflow-x-auto">
        <h3 className="text-lg font-semibold text-foreground mb-6">Lista de Usuários</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Nome</th>
              <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Email</th>
              <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Role</th>
              <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Ações</th>
            </tr>
          </thead>
          <tbody>
            {allUsers?.map((user) => (
              <tr key={user.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                <td className="py-3 px-4 text-foreground">{user.name || "N/A"}</td>
                <td className="py-3 px-4 text-foreground">{user.email || "N/A"}</td>
                <td className="py-3 px-4">
                  <select
                    value={user.role}
                    onChange={(e) => handleChangeRole(user.id, e.target.value as "user" | "admin")}
                    className="px-3 py-1 bg-input border border-border rounded text-foreground text-xs"
                  >
                    <option value="user">Usuário</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
                <td className="py-3 px-4">
                  <button
                    onClick={() => handleDeleteUser(user.id)}
                    className="p-1 hover:bg-destructive/10 rounded transition-colors"
                    disabled={deleteUserMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}

export default function Admin() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("results");
  const [editingId, setEditingId] = useState<number | null>(null);

  // Formulário de Resultados
  const [resultsForm, setResultsForm] = useState({
    strategyId: 1,
    month: new Date().toISOString().slice(0, 7),
    initialBalance: 10000,
    finalBalance: 10500,
    maxDrawdown: 200,
  });

  // Formulário de CDI
  const [cdiForm, setCdiForm] = useState({
    month: new Date().toISOString().slice(0, 7),
    monthlyRate: 50,
    accumulatedRate: 600,
  });

  const { data: strategies } = trpc.strategies.list.useQuery();
  const { data: monthlyResults, refetch: refetchResults } = trpc.strategies.getMonthlyResults.useQuery(
    { strategyId: resultsForm.strategyId },
    { enabled: resultsForm.strategyId !== null }
  );
  const { data: allCdiData, refetch: refetchCdi } = trpc.strategies.getCdiData.useQuery();

  const updateResultsMutation = trpc.strategies.updateMonthlyResult.useMutation();
  const updateCdiMutation = trpc.strategies.updateCdiData.useMutation();
  const deleteResultsMutation = trpc.strategies.deleteMonthlyResult.useMutation();
  const deleteCdiMutation = trpc.strategies.deleteCdiData.useMutation();

  // Calcular automaticamente Lucro/Prejuízo e Rentabilidade
  const calculatedProfitLoss = resultsForm.finalBalance - resultsForm.initialBalance;
  const calculatedProfitPercentage = resultsForm.initialBalance > 0
    ? Math.round((calculatedProfitLoss / resultsForm.initialBalance) * 10000)
    : 0;

  const handleUpdateResults = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateResultsMutation.mutateAsync({
        ...resultsForm,
        profitLoss: calculatedProfitLoss,
        profitPercentage: calculatedProfitPercentage,
      });
      toast.success("Resultados atualizados com sucesso!");
      setEditingId(null);
      setResultsForm({
        strategyId: 1,
        month: new Date().toISOString().slice(0, 7),
        initialBalance: 10000,
        finalBalance: 10500,
        maxDrawdown: 200,
      });
      refetchResults();
    } catch (error) {
      toast.error("Erro ao atualizar resultados");
    }
  };

  const handleDeleteResult = async (id: number) => {
    if (!confirm("Tem certeza que deseja deletar este registro?")) return;
    try {
      await deleteResultsMutation.mutateAsync(id);
      toast.success("Registro deletado com sucesso!");
      refetchResults();
    } catch (error) {
      toast.error("Erro ao deletar registro");
    }
  };

  const handleUpdateCdi = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateCdiMutation.mutateAsync(cdiForm);
      toast.success("Dados do CDI atualizados com sucesso!");
      setCdiForm({
        month: new Date().toISOString().slice(0, 7),
        monthlyRate: 50,
        accumulatedRate: 600,
      });
      refetchCdi();
    } catch (error) {
      toast.error("Erro ao atualizar CDI");
    }
  };

  const handleDeleteCdi = async (month: string) => {
    if (!confirm("Tem certeza que deseja deletar este registro?")) return;
    try {
      await deleteCdiMutation.mutateAsync(month);
      toast.success("Registro deletado com sucesso!");
      refetchCdi();
    } catch (error) {
      toast.error("Erro ao deletar registro");
    }
  };

  if (user?.role !== "admin") {
    return (
      <div className="container py-8">
        <div className="text-destructive">Você não tem permissão para acessar esta página</div>
      </div>
    );
  }

  return (
    <div className="container py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Painel Administrativo</h1>
        <p className="text-muted-foreground">Gerencie estratégias, usuários e dados do sistema</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="results">Resultados Mensais</TabsTrigger>
          <TabsTrigger value="cdi">Dados CDI</TabsTrigger>
          <TabsTrigger value="users">Gerenciar Usuários</TabsTrigger>
        </TabsList>

        {/* Resultados Mensais */}
        <TabsContent value="results" className="space-y-6">
          <Card className="p-6 border border-border bg-card">
            <h3 className="text-lg font-semibold text-foreground mb-6">Inserir Resultado Mensal</h3>
            <form onSubmit={handleUpdateResults} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Estratégia</label>
                  <select
                    value={resultsForm.strategyId}
                    onChange={(e) => setResultsForm({ ...resultsForm, strategyId: parseInt(e.target.value) })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  >
                    {strategies?.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Mês</label>
                  <input
                    type="month"
                    value={resultsForm.month}
                    onChange={(e) => setResultsForm({ ...resultsForm, month: e.target.value })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Saldo Inicial (USD)</label>
                  <input
                    type="number"
                    value={resultsForm.initialBalance}
                    onChange={(e) => setResultsForm({ ...resultsForm, initialBalance: parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Saldo Final (USD)</label>
                  <input
                    type="number"
                    value={resultsForm.finalBalance}
                    onChange={(e) => setResultsForm({ ...resultsForm, finalBalance: parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Drawdown Máximo (USD)</label>
                  <input
                    type="number"
                    value={resultsForm.maxDrawdown}
                    onChange={(e) => setResultsForm({ ...resultsForm, maxDrawdown: parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Lucro/Prejuízo (Automático)</label>
                  <input
                    type="number"
                    value={calculatedProfitLoss}
                    disabled
                    className="w-full px-4 py-2 bg-secondary border border-border rounded text-foreground opacity-60"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Rentabilidade (%)</label>
                  <input
                    type="number"
                    value={(calculatedProfitPercentage / 100).toFixed(2)}
                    disabled
                    className="w-full px-4 py-2 bg-secondary border border-border rounded text-foreground opacity-60"
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={updateResultsMutation.isPending}
              >
                {updateResultsMutation.isPending ? "Salvando..." : "Salvar Resultado"}
              </Button>
            </form>
          </Card>

          {/* Histórico de Resultados */}
          <Card className="p-6 border border-border bg-card overflow-x-auto">
            <h3 className="text-lg font-semibold text-foreground mb-6">Histórico de Resultados</h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Mês</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Saldo Inicial</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Saldo Final</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Lucro/Prejuízo</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Rentabilidade</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Ações</th>
                </tr>
              </thead>
              <tbody>
                {monthlyResults?.map((result) => (
                  <tr key={result.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="py-3 px-4 text-foreground">{result.month}</td>
                    <td className="py-3 px-4 text-foreground">${result.initialBalance.toLocaleString("en-US")}</td>
                    <td className="py-3 px-4 text-foreground">${result.finalBalance.toLocaleString("en-US")}</td>
                    <td className={`py-3 px-4 ${result.profitLoss >= 0 ? "text-success" : "text-destructive"}`}>
                      ${result.profitLoss.toLocaleString("en-US")}
                    </td>
                    <td className={`py-3 px-4 ${result.profitPercentage >= 0 ? "text-success" : "text-destructive"}`}>
                      {(result.profitPercentage / 100).toFixed(2)}%
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleDeleteResult(result.id)}
                        className="p-1 hover:bg-destructive/10 rounded transition-colors"
                        disabled={deleteResultsMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </TabsContent>

        {/* Dados CDI */}
        <TabsContent value="cdi" className="space-y-6">
          <Card className="p-6 border border-border bg-card">
            <h3 className="text-lg font-semibold text-foreground mb-6">Inserir Dados CDI</h3>
            <form onSubmit={handleUpdateCdi} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Mês</label>
                  <input
                    type="month"
                    value={cdiForm.month}
                    onChange={(e) => setCdiForm({ ...cdiForm, month: e.target.value })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Taxa Mensal (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={cdiForm.monthlyRate}
                    onChange={(e) => setCdiForm({ ...cdiForm, monthlyRate: parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Taxa Acumulada (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={cdiForm.accumulatedRate}
                    onChange={(e) => setCdiForm({ ...cdiForm, accumulatedRate: parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 bg-input border border-border rounded text-foreground"
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={updateCdiMutation.isPending}
              >
                {updateCdiMutation.isPending ? "Salvando..." : "Salvar Dados CDI"}
              </Button>
            </form>
          </Card>

          {/* Histórico CDI */}
          <Card className="p-6 border border-border bg-card overflow-x-auto">
            <h3 className="text-lg font-semibold text-foreground mb-6">Histórico CDI</h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Mês</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Taxa Mensal</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Taxa Acumulada</th>
                  <th className="text-left py-3 px-4 text-muted-foreground font-semibold">Ações</th>
                </tr>
              </thead>
              <tbody>
                {allCdiData?.map((cdi) => (
                  <tr key={cdi.month} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="py-3 px-4 text-foreground">{cdi.month}</td>
                    <td className="py-3 px-4 text-foreground">{cdi.monthlyRate.toFixed(2)}%</td>
                    <td className="py-3 px-4 text-foreground">{cdi.accumulatedRate.toFixed(2)}%</td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleDeleteCdi(cdi.month)}
                        className="p-1 hover:bg-destructive/10 rounded transition-colors"
                        disabled={deleteCdiMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </TabsContent>

        {/* Gerenciar Usuários */}
        <TabsContent value="users" className="space-y-6">
          <UsersTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
