import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Mail, Clock, Shield, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Profile() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      // Aguardar um pouco para garantir que o cookie foi limpo
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
    } catch (error) {
      console.error("Erro ao fazer logout", error);
      window.location.href = "/";
    }
  };

  if (!user) {
    return (
      <div className="container py-8">
        <Card className="p-8 text-center border border-border bg-card">
          <p className="text-muted-foreground">Carregando perfil...</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Meu Perfil</h1>
        <p className="text-muted-foreground">Informações da sua conta</p>
      </div>

      {/* Informações Pessoais */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-6">Informações Pessoais</h3>
        <div className="space-y-4">
          {/* Nome */}
          <div className="flex items-start gap-4">
            <User className="w-5 h-5 text-primary mt-1" />
            <div>
              <p className="text-sm text-muted-foreground">Nome</p>
              <p className="text-foreground font-semibold">{user.name || "Não informado"}</p>
            </div>
          </div>

          {/* Email */}
          <div className="flex items-start gap-4 pt-4 border-t border-border">
            <Mail className="w-5 h-5 text-primary mt-1" />
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="text-foreground font-semibold">{user.email || "Não informado"}</p>
            </div>
          </div>

          {/* Método de Login */}
          <div className="flex items-start gap-4 pt-4 border-t border-border">
            <Shield className="w-5 h-5 text-primary mt-1" />
            <div>
              <p className="text-sm text-muted-foreground">Método de Login</p>
              <p className="text-foreground font-semibold capitalize">{user.loginMethod || "Não informado"}</p>
            </div>
          </div>

          {/* Último Acesso */}
          <div className="flex items-start gap-4 pt-4 border-t border-border">
            <Clock className="w-5 h-5 text-primary mt-1" />
            <div>
              <p className="text-sm text-muted-foreground">Último Acesso</p>
              <p className="text-foreground font-semibold">
                {new Date(user.lastSignedIn).toLocaleString("pt-BR")}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Status da Conta */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-6">Status da Conta</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-secondary rounded">
            <div>
              <p className="text-sm text-muted-foreground">Tipo de Conta</p>
              <p className="text-foreground font-semibold capitalize">
                {user.role === "admin" ? "Administrador" : "Membro"}
              </p>
            </div>
            <div
              className={`px-3 py-1 rounded text-sm font-semibold ${
                user.role === "admin"
                  ? "bg-primary text-primary-foreground"
                  : "bg-accent text-accent-foreground"
              }`}
            >
              {user.role === "admin" ? "Admin" : "Usuário"}
            </div>
          </div>

          <div className="flex items-center justify-between p-4 bg-secondary rounded">
            <div>
              <p className="text-sm text-muted-foreground">Data de Criação</p>
              <p className="text-foreground font-semibold">
                {new Date(user.createdAt).toLocaleDateString("pt-BR")}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Segurança */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-6">Segurança</h3>
        <div className="space-y-4">
          <p className="text-muted-foreground text-sm">
            Sua conta está protegida pela autenticação OAuth da Manus. Para alterar sua senha ou configurações de segurança, acesse sua conta no portal de autenticação.
          </p>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            Gerenciar Segurança
          </Button>
        </div>
      </Card>

      {/* Preferências */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-6">Preferências</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-secondary rounded">
            <div>
              <p className="text-foreground font-semibold">Notificações por Email</p>
              <p className="text-sm text-muted-foreground">Receba atualizações importantes</p>
            </div>
            <input type="checkbox" defaultChecked className="w-5 h-5" />
          </div>
        </div>
      </Card>

      {/* Sair */}
      <Card className="p-6 border border-border bg-card">
        <h3 className="text-lg font-semibold text-foreground mb-6">Sessão</h3>
        <Button
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
          className="w-full bg-destructive text-destructive-foreground hover:bg-destructive/90 flex items-center justify-center gap-2"
        >
          <LogOut className="w-4 h-4" />
          {logoutMutation.isPending ? "Saindo..." : "Sair da Conta"}
        </Button>
      </Card>
    </div>
  );
}
