import { z } from "zod";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  getAllUsers,
  deleteUser,
  updateUserRole,
  createUserAccount,
  createRoboForexAccount,
  getUserRoboForexAccounts,
  createEmailConfirmation,
  getEmailConfirmationByToken,
  confirmEmail,
  deleteUserAccount,
  deleteRoboForexAccount,
  getDb,
  getUserByEmail,
} from "../db";
import { nanoid } from "nanoid";
import bcrypt from "bcrypt";
import { users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { sdk } from "../_core/sdk";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "../_core/cookies";

export const usersRouter = router({
  /**
   * Admin: Listar todos os usuários
   */
  listAll: adminProcedure.query(async () => {
    return getAllUsers();
  }),

  /**
   * Admin: Deletar usuário
   */
  delete: adminProcedure
    .input(z.number())
    .mutation(async ({ input }) => {
      await deleteUser(input);
      return { success: true };
    }),

  /**
   * Admin: Atualizar role do usuário
   */
  updateRole: adminProcedure
    .input(z.object({ userId: z.number(), role: z.enum(["user", "admin"]) }))
    .mutation(async ({ input }) => {
      await updateUserRole(input.userId, input.role);
      return { success: true };
    }),



  /**
   * Público: Listar contas RoboForex do usuário
   */
  getRoboForexAccounts: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new Error("Unauthorized");
    return getUserRoboForexAccounts(ctx.user.id);
  }),

  /**
   * Público: Criar conta RoboForex
   */
  createRoboForexAccount: protectedProcedure
    .input(
      z.object({
        strategyId: z.number(),
        accountNumber: z.string(),
        platform: z.enum(["mt4", "mt5"]),
        depositedAmount: z.number().min(200),
        depositDate: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");

      await createRoboForexAccount({
        userId: ctx.user.id,
        strategyId: input.strategyId,
        accountNumber: input.accountNumber,
        platform: input.platform,
        depositedAmount: input.depositedAmount,
        depositDate: new Date(input.depositDate),
      });

      return { success: true };
    }),

  /**
   * Público: Deletar conta RoboForex
   */
  deleteRoboForexAccount: protectedProcedure
    .input(z.number())
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Unauthorized");
      await deleteRoboForexAccount(input);
      return { success: true };
    }),

  /**
   * Público: Criar token de confirmação de email
   */
  requestEmailConfirmation: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      const token = nanoid(32);
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 horas

      await createEmailConfirmation({
        email: input.email,
        token,
        confirmed: 0,
        expiresAt,
      });

      return { success: true, token };
    }),

  /**
   * Público: Confirmar email
   */
  confirmEmail: publicProcedure
    .input(z.string())
    .mutation(async ({ input: token }) => {
      const confirmation = await getEmailConfirmationByToken(token);

      if (!confirmation) {
        throw new Error("Token inválido ou expirado");
      }

      if (confirmation.expiresAt < new Date()) {
        throw new Error("Token expirado");
      }

      await confirmEmail(token);
      return { success: true, email: confirmation.email };
    }),

  /**
   * Público: Cadastrar novo usuário com email/senha
   */
  signup: publicProcedure
    .input(z.object({
      name: z.string().min(1),
      email: z.string().email(),
      password: z.string().min(8),
      roboForexAccount: z.string().regex(/^\d+$/),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Verificar se email já existe
      const existingUser = await db.select().from(users).where(eq(users.email, input.email)).limit(1);
      if (existingUser.length > 0) {
        throw new Error("Email já cadastrado");
      }

      // Hash da senha
      const passwordHash = await bcrypt.hash(input.password, 10);

      // Gerar openId único para usuários email/senha
      const openId = nanoid(32);

      // Criar usuário
      await db.insert(users).values({
        openId,
        email: input.email,
        name: input.name,
        passwordHash,
        loginMethod: "email",
        role: "user",
      });

      return { success: true, message: "Cadastro realizado com sucesso" };
    }),

  /**
   * Público: Login com email/senha
   */
  login: publicProcedure
    .input(z.object({
      email: z.string().email(),
      password: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      console.log("[Login] Attempting login for email:", input.email);
      console.log("[Login] Input password:", input.password.substring(0, 3) + "***");
      const user = await getUserByEmail(input.email);
      console.log("[Login] Found user:", user ? { id: user.id, email: user.email, name: user.name, hasPassword: !!user.passwordHash } : "NOT FOUND");

      if (!user || !user.passwordHash) {
        console.log("[Login] User not found or no password hash");
        throw new Error("Email ou senha inválidos");
      }

      // Validar senha
      const isPasswordValid = await bcrypt.compare(input.password, user.passwordHash);
      if (!isPasswordValid) {
        console.log("[Login] Invalid password");
        throw new Error("Email ou senha inválidos");
      }

      // Criar token de sessão
      console.log("[Login] User data:", { id: user.id, name: user.name, openId: user.openId });
      const sessionToken = await sdk.createEmailSessionToken(user.id, user.name || "");
      console.log("[Login] Session token created for user ID:", user.id);

      // Definir cookie de sessão
      const cookieOptions = getSessionCookieOptions(ctx.req);
      console.log("[Login] Cookie options:", cookieOptions);
      ctx.res.cookie(COOKIE_NAME, sessionToken, cookieOptions);
      console.log("[Login] Cookie set successfully");

      return { success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
    }),
});
