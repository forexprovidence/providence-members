import { describe, it, expect, beforeEach } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("strategiesRouter", () => {
  describe("list", () => {
    it("should return active strategies", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const strategies = await caller.strategies.list();

      expect(Array.isArray(strategies)).toBe(true);
    });
  });

  describe("updateMonthlyResult", () => {
    it("should allow admin to update monthly results", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.strategies.updateMonthlyResult({
        strategyId: 1,
        month: "2025-01",
        initialBalance: 10000,
        finalBalance: 10500,
        profitLoss: 500,
        profitPercentage: 500,
        maxDrawdown: 200,
      });

      expect(result.success).toBe(true);
    });

    it("should deny non-admin users from updating monthly results", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.strategies.updateMonthlyResult({
          strategyId: 1,
          month: "2025-01",
          initialBalance: 10000,
          finalBalance: 10500,
          profitLoss: 500,
          profitPercentage: 500,
          maxDrawdown: 200,
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });

  describe("updateCdiData", () => {
    it("should allow admin to update CDI data", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.strategies.updateCdiData({
        month: "2025-01",
        monthlyRate: 50,
        accumulatedRate: 600,
      });

      expect(result.success).toBe(true);
    });

    it("should deny non-admin users from updating CDI data", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.strategies.updateCdiData({
          month: "2025-01",
          monthlyRate: 50,
          accumulatedRate: 600,
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });

  describe("getUserAccounts", () => {
    it("should require authentication", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const accounts = await caller.strategies.getUserAccounts();

      expect(Array.isArray(accounts)).toBe(true);
    });
  });

  describe("getCdiData", () => {
    it("should return CDI data publicly", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const cdiData = await caller.strategies.getCdiData();

      expect(Array.isArray(cdiData)).toBe(true);
    });
  });
});
