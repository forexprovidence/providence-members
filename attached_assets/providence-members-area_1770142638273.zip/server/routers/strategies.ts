import { z } from "zod";
import { publicProcedure, router, protectedProcedure, adminProcedure } from "../_core/trpc";
import {
  getActiveStrategies,
  getStrategyMonthlyResults,
  getCdiData,
  upsertMonthlyResult,
  upsertCdiData,
  getUserAccounts,
  getAccountHistory,
  deleteMonthlyResult,
  deleteCdiData,
} from "../db";

export const strategiesRouter = router({
  /**
   * Obter todas as estratégias ativas
   */
  list: publicProcedure.query(async () => {
    return getActiveStrategies();
  }),

  /**
   * Obter resultados mensais de uma estratégia
   */
  getMonthlyResults: publicProcedure
    .input(z.object({ strategyId: z.number() }))
    .query(async ({ input }) => {
      return getStrategyMonthlyResults(input.strategyId);
    }),

  /**
   * Obter dados do CDI
   */
  getCdiData: publicProcedure.query(async () => {
    return getCdiData();
  }),

  /**
   * Admin: Inserir ou atualizar resultado mensal de uma estratégia
   */
  updateMonthlyResult: adminProcedure
    .input(
      z.object({
        strategyId: z.number(),
        month: z.string(), // "2025-01"
        initialBalance: z.number(),
        finalBalance: z.number(),
        profitLoss: z.number(),
        profitPercentage: z.number(),
        maxDrawdown: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      await upsertMonthlyResult({
        strategyId: input.strategyId,
        month: input.month,
        initialBalance: input.initialBalance,
        finalBalance: input.finalBalance,
        profitLoss: input.profitLoss,
        profitPercentage: input.profitPercentage,
        maxDrawdown: input.maxDrawdown,
      });
      return { success: true };
    }),

  /**
   * Admin: Inserir ou atualizar dados do CDI
   */
  updateCdiData: adminProcedure
    .input(
      z.object({
        month: z.string(), // "2025-01"
        monthlyRate: z.number(),
        accumulatedRate: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      await upsertCdiData({
        month: input.month,
        monthlyRate: input.monthlyRate,
        accumulatedRate: input.accumulatedRate,
      });
      return { success: true };
    }),

  /**
   * Usuário: Obter suas contas em estratégias
   */
  getUserAccounts: protectedProcedure.query(async ({ ctx }) => {
    return getUserAccounts(ctx.user.id);
  }),

  /**
   * Usuário: Obter histórico de uma conta
   */
  getAccountHistory: protectedProcedure
    .input(z.object({ userAccountId: z.number() }))
    .query(async ({ input }) => {
      return getAccountHistory(input.userAccountId);
    }),

  /**
   * Admin: Deletar resultado mensal
   */
  deleteMonthlyResult: adminProcedure
    .input(z.number())
    .mutation(async ({ input }) => {
      await deleteMonthlyResult(input);
      return { success: true };
    }),

  /**
   * Admin: Deletar dados do CDI
   */
  deleteCdiData: adminProcedure
    .input(z.string())
    .mutation(async ({ input }) => {
      await deleteCdiData(input);
      return { success: true };
    }),
});
