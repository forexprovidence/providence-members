import { eq, and, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  strategies,
  monthlyResults,
  InsertMonthlyResult,
  userAccounts,
  InsertUserAccount,
  accountHistory,
  cdiData,
  InsertCdiData,
  roboForexAccounts,
  InsertRoboForexAccount,
  emailConfirmations,
  InsertEmailConfirmation,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Obter usuário por ID
 */
export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Obter usuário por email
 */
export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Obter estratégias ativas
 */
export async function getActiveStrategies() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(strategies).where(eq(strategies.isActive, 1));
}

/**
 * Obter resultados mensais de uma estratégia
 */
export async function getStrategyMonthlyResults(strategyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(monthlyResults)
    .where(eq(monthlyResults.strategyId, strategyId))
    .orderBy(monthlyResults.month);
}

/**
 * Obter conta de usuário em uma estratégia
 */
export async function getUserAccount(userId: number, strategyId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(userAccounts)
    .where(
      and(
        eq(userAccounts.userId, userId),
        eq(userAccounts.strategyId, strategyId)
      )
    )
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Obter todas as contas de um usuário com dados de RoboForex
 */
export async function getUserAccounts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const accounts = await db.select().from(userAccounts).where(eq(userAccounts.userId, userId));
  
  // Buscar dados de RoboForex para cada conta
  const accountsWithRobo = await Promise.all(
    accounts.map(async (account) => {
      const roboAccounts = await db
        .select()
        .from(roboForexAccounts)
        .where(
          and(
            eq(roboForexAccounts.userId, userId),
            eq(roboForexAccounts.strategyId, account.strategyId)
          )
        )
        .limit(1);
      
      const roboAccount = roboAccounts[0];
      return {
        ...account,
        accountNumber: roboAccount?.accountNumber || "N/A",
        platform: roboAccount?.platform || "N/A",
      };
    })
  );
  
  return accountsWithRobo;
}

/**
 * Obter histórico de conta
 */
export async function getAccountHistory(userAccountId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(accountHistory)
    .where(eq(accountHistory.userAccountId, userAccountId))
    .orderBy(accountHistory.month);
}

/**
 * Obter dados do CDI
 */
export async function getCdiData() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(cdiData).orderBy(cdiData.month);
}

/**
 * Inserir ou atualizar resultado mensal
 */
export async function upsertMonthlyResult(data: InsertMonthlyResult): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db
    .insert(monthlyResults)
    .values(data)
    .onDuplicateKeyUpdate({
      set: {
        finalBalance: data.finalBalance,
        profitLoss: data.profitLoss,
        profitPercentage: data.profitPercentage,
        maxDrawdown: data.maxDrawdown,
        updatedAt: new Date(),
      },
    });
}

/**
 * Inserir ou atualizar dados do CDI
 */
export async function upsertCdiData(data: InsertCdiData): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db
    .insert(cdiData)
    .values(data)
    .onDuplicateKeyUpdate({
      set: {
        monthlyRate: data.monthlyRate,
        accumulatedRate: data.accumulatedRate,
        updatedAt: new Date(),
      },
    });
}

// TODO: add feature queries here as your schema grows.

/**
 * Deletar resultado mensal
 */
export async function deleteMonthlyResult(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(monthlyResults).where(eq(monthlyResults.id, id));
}

/**
 * Deletar dados do CDI
 */
export async function deleteCdiData(month: string): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(cdiData).where(eq(cdiData.month, month));
}

/**
 * Listar todos os usuários
 */
export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users);
}

/**
 * Deletar usuário
 */
export async function deleteUser(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(users).where(eq(users.id, id));
}

/**
 * Atualizar role do usuário
 */
export async function updateUserRole(id: number, role: "user" | "admin"): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, id));
}

/**
 * Criar conta de usuário em estratégia
 */
export async function createUserAccount(data: InsertUserAccount): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(userAccounts).values(data);
}

/**
 * Criar conta RoboForex
 */
export async function createRoboForexAccount(data: InsertRoboForexAccount): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(roboForexAccounts).values(data);
}

/**
 * Obter contas RoboForex do usuário
 */
export async function getUserRoboForexAccounts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(roboForexAccounts).where(eq(roboForexAccounts.userId, userId));
}

/**
 * Criar confirmação de email
 */
export async function createEmailConfirmation(data: InsertEmailConfirmation): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(emailConfirmations).values(data);
}

/**
 * Obter confirmação de email por token
 */
export async function getEmailConfirmationByToken(token: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(emailConfirmations)
    .where(eq(emailConfirmations.token, token))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/**
 * Confirmar email
 */
export async function confirmEmail(token: string): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(emailConfirmations).set({ confirmed: 1 }).where(eq(emailConfirmations.token, token));
}


/**
 * Obter contas de usuário por estratégia
 */
export async function getUserAccountsByStrategy(userId: number, strategyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(userAccounts)
    .where(
      and(
        eq(userAccounts.userId, userId),
        eq(userAccounts.strategyId, strategyId)
      )
    );
}



/**
 * Deletar conta de usuário
 */
export async function deleteUserAccount(accountId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(userAccounts).where(eq(userAccounts.id, accountId));
}

/**
 * Deletar conta RoboForex
 */
export async function deleteRoboForexAccount(accountId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(roboForexAccounts).where(eq(roboForexAccounts.id, accountId));
}

/**
 * Atualizar conta de usuário
 */
export async function updateUserAccount(
  accountId: number,
  data: Partial<InsertUserAccount>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(userAccounts).set(data).where(eq(userAccounts.id, accountId));
}

/**
 * Atualizar conta RoboForex
 */
export async function updateRoboForexAccount(
  accountId: number,
  data: Partial<InsertRoboForexAccount>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(roboForexAccounts).set(data).where(eq(roboForexAccounts.id, accountId));
}

/**
 * Calcular lucro de uma conta baseado em resultados mensais
 */
export async function calculateAccountProfit(
  userAccountId: number,
  depositDate: Date
): Promise<{ totalProfit: number; totalProfitPercentage: number }> {
  const db = await getDb();
  if (!db) return { totalProfit: 0, totalProfitPercentage: 0 };

  // Obter conta do usuário
  const account = await db
    .select()
    .from(userAccounts)
    .where(eq(userAccounts.id, userAccountId))
    .limit(1);

  if (!account || account.length === 0) {
    return { totalProfit: 0, totalProfitPercentage: 0 };
  }

  const userAccount = account[0];
  const initialDeposit = userAccount.initialDeposit;

  // Obter resultados mensais da estratégia a partir da data de depósito
  const results = await db
    .select()
    .from(monthlyResults)
    .where(
      and(
        eq(monthlyResults.strategyId, userAccount.strategyId),
        gte(monthlyResults.month, depositDate.toISOString().slice(0, 7))
      )
    )
    .orderBy(monthlyResults.month);

  if (results.length === 0) {
    return { totalProfit: 0, totalProfitPercentage: 0 };
  }

  // Calcular lucro acumulado
  let currentBalance = initialDeposit;
  let totalProfit = 0;

  for (const result of results) {
    const monthlyReturnPercentage = result.profitPercentage / 100;
    const monthlyProfit = currentBalance * monthlyReturnPercentage;
    currentBalance += monthlyProfit;
    totalProfit += monthlyProfit;
  }

  const totalProfitPercentage = ((currentBalance - initialDeposit) / initialDeposit) * 100;

  return {
    totalProfit: Math.round(totalProfit),
    totalProfitPercentage: Math.round(totalProfitPercentage * 100) / 100,
  };
}

/**
 * Obter contas RoboForex por estratégia
 */
export async function getRoboForexAccountsByStrategy(userId: number, strategyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(roboForexAccounts)
    .where(
      and(
        eq(roboForexAccounts.userId, userId),
        eq(roboForexAccounts.strategyId, strategyId)
      )
    );
}
