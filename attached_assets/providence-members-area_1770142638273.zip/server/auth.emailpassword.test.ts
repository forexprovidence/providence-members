import { describe, expect, it, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import bcrypt from "bcrypt";
import * as db from "./db";

type CookieCall = {
  name: string;
  value: string;
  options: Record<string, unknown>;
};

function createPublicContext(): { ctx: TrpcContext; setCookies: CookieCall[] } {
  const setCookies: CookieCall[] = [];

  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      cookie: (name: string, value: string, options: Record<string, unknown>) => {
        setCookies.push({ name, value, options });
      },
    } as TrpcContext["res"],
  };

  return { ctx, setCookies };
}

describe("users.signup and users.login", () => {
  const testEmail = `test-${Date.now()}@example.com`;
  const testPassword = "SecurePassword123";
  const testName = "Test User";

  it("should successfully signup a new user with email/password", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.users.signup({
      name: testName,
      email: testEmail,
      password: testPassword,
      roboForexAccount: "123456",
    });

    expect(result).toEqual({
      success: true,
      message: "Cadastro realizado com sucesso",
    });

    // Verify user was created in database
    const user = await db.getUserByEmail(testEmail);
    expect(user).toBeDefined();
    expect(user?.name).toBe(testName);
    expect(user?.email).toBe(testEmail);
    expect(user?.loginMethod).toBe("email");
    expect(user?.passwordHash).toBeDefined();

    // Verify password hash is valid
    const isPasswordValid = await bcrypt.compare(testPassword, user?.passwordHash || "");
    expect(isPasswordValid).toBe(true);
  });

  it("should reject signup with duplicate email", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Try to signup with same email
    try {
      await caller.users.signup({
        name: "Another User",
        email: testEmail,
        password: "AnotherPassword123",
        roboForexAccount: "654321",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Email já cadastrado");
    }
  });

  it("should successfully login with correct email/password", async () => {
    const { ctx, setCookies } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.users.login({
      email: testEmail,
      password: testPassword,
    });

    expect(result.success).toBe(true);
    expect(result.user).toBeDefined();
    expect(result.user?.email).toBe(testEmail);
    expect(result.user?.name).toBe(testName);
    expect(result.user?.role).toBe("user");

    // Verify session cookie was set
    expect(setCookies).toHaveLength(1);
    expect(setCookies[0]?.name).toBeDefined();
    expect(setCookies[0]?.value).toBeDefined();
  });

  it("should reject login with incorrect password", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.users.login({
        email: testEmail,
        password: "WrongPassword123",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Email ou senha inválidos");
    }
  });

  it("should reject login with non-existent email", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.users.login({
        email: "nonexistent@example.com",
        password: testPassword,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("Email ou senha inválidos");
    }
  });

  it("should reject signup with password too short", async () => {
    const { ctx } = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.users.signup({
        name: "Short Pass User",
        email: `short-${Date.now()}@example.com`,
        password: "short",
        roboForexAccount: "123456",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });
});
