ALTER TABLE `roboForexAccounts` DROP INDEX `roboForexAccounts_accountNumber_unique`;--> statement-breakpoint
ALTER TABLE `roboForexAccounts` ADD `strategyId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `roboForexAccounts` ADD `depositDate` timestamp NOT NULL;