CREATE TABLE `emailConfirmations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`token` varchar(255) NOT NULL,
	`confirmed` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	CONSTRAINT `emailConfirmations_id` PRIMARY KEY(`id`),
	CONSTRAINT `emailConfirmations_email_unique` UNIQUE(`email`),
	CONSTRAINT `emailConfirmations_token_unique` UNIQUE(`token`)
);
--> statement-breakpoint
CREATE TABLE `roboForexAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`accountNumber` varchar(20) NOT NULL,
	`platform` enum('mt4','mt5') NOT NULL,
	`depositedAmount` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `roboForexAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `roboForexAccounts_accountNumber_unique` UNIQUE(`accountNumber`)
);
