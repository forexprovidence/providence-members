CREATE TABLE `accountHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userAccountId` int NOT NULL,
	`month` varchar(7) NOT NULL,
	`balance` int NOT NULL,
	`profitLoss` int NOT NULL,
	`profitPercentage` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `accountHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cdiData` (
	`id` int AUTO_INCREMENT NOT NULL,
	`month` varchar(7) NOT NULL,
	`monthlyRate` int NOT NULL,
	`accumulatedRate` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cdiData_id` PRIMARY KEY(`id`),
	CONSTRAINT `cdiData_month_unique` UNIQUE(`month`)
);
--> statement-breakpoint
CREATE TABLE `monthlyResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`strategyId` int NOT NULL,
	`month` varchar(7) NOT NULL,
	`initialBalance` int NOT NULL,
	`finalBalance` int NOT NULL,
	`profitLoss` int NOT NULL,
	`profitPercentage` int NOT NULL,
	`maxDrawdown` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monthlyResults_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `strategies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`type` enum('ultimate','alavancado') NOT NULL,
	`riskLevel` enum('conservative','aggressive') NOT NULL,
	`minimumDeposit` int NOT NULL,
	`commissionPercentage` int NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `strategies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`strategyId` int NOT NULL,
	`initialDeposit` int NOT NULL,
	`currentBalance` int NOT NULL,
	`totalProfit` int NOT NULL,
	`totalProfitPercentage` int NOT NULL,
	`maxDrawdown` int NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userAccounts_id` PRIMARY KEY(`id`)
);
