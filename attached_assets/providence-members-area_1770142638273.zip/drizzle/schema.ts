import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Estratégias de investimento
 */
export const strategies = mysqlTable("strategies", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(), // "Ultimate" ou "Alavancado"
  description: text("description"),
  type: mysqlEnum("type", ["ultimate", "alavancado"]).notNull(),
  riskLevel: mysqlEnum("riskLevel", ["conservative", "aggressive"]).notNull(),
  minimumDeposit: int("minimumDeposit").notNull(), // em USD
  commissionPercentage: int("commissionPercentage").notNull(), // percentual de comissão
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = typeof strategies.$inferInsert;

/**
 * Resultados mensais por estratégia (alimentado pelo admin)
 */
export const monthlyResults = mysqlTable("monthlyResults", {
  id: int("id").autoincrement().primaryKey(),
  strategyId: int("strategyId").notNull(),
  month: varchar("month", { length: 7 }).notNull(), // "2025-01"
  initialBalance: int("initialBalance").notNull(), // saldo inicial em USD
  finalBalance: int("finalBalance").notNull(), // saldo final em USD
  profitLoss: int("profitLoss").notNull(), // lucro/prejuízo em USD
  profitPercentage: int("profitPercentage").notNull(), // percentual de lucro (multiplicado por 100)
  maxDrawdown: int("maxDrawdown").notNull(), // drawdown máximo em percentual
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MonthlyResult = typeof monthlyResults.$inferSelect;
export type InsertMonthlyResult = typeof monthlyResults.$inferInsert;

/**
 * Contas de usuários em estratégias
 */
export const userAccounts = mysqlTable("userAccounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  strategyId: int("strategyId").notNull(),
  initialDeposit: int("initialDeposit").notNull(), // depósito inicial em USD
  currentBalance: int("currentBalance").notNull(), // saldo atual em USD
  totalProfit: int("totalProfit").notNull(), // lucro total em USD
  totalProfitPercentage: int("totalProfitPercentage").notNull(), // percentual total
  maxDrawdown: int("maxDrawdown").notNull(), // drawdown máximo registrado
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserAccount = typeof userAccounts.$inferSelect;
export type InsertUserAccount = typeof userAccounts.$inferInsert;

/**
 * Histórico de transações/atualizações de saldo
 */
export const accountHistory = mysqlTable("accountHistory", {
  id: int("id").autoincrement().primaryKey(),
  userAccountId: int("userAccountId").notNull(),
  month: varchar("month", { length: 7 }).notNull(), // "2025-01"
  balance: int("balance").notNull(), // saldo no mês em USD
  profitLoss: int("profitLoss").notNull(), // lucro/prejuízo do mês em USD
  profitPercentage: int("profitPercentage").notNull(), // percentual do mês
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AccountHistory = typeof accountHistory.$inferSelect;
export type InsertAccountHistory = typeof accountHistory.$inferInsert;

/**
 * Dados do CDI para comparação (atualizado periodicamente)
 */
export const cdiData = mysqlTable("cdiData", {
  id: int("id").autoincrement().primaryKey(),
  month: varchar("month", { length: 7 }).notNull().unique(), // "2025-01"
  monthlyRate: int("monthlyRate").notNull(), // taxa mensal em percentual (multiplicado por 100)
  accumulatedRate: int("accumulatedRate").notNull(), // taxa acumulada
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CdiData = typeof cdiData.$inferSelect;
export type InsertCdiData = typeof cdiData.$inferInsert;

/**
 * Contas RoboForex dos usuários
 */
export const roboForexAccounts = mysqlTable("roboForexAccounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  strategyId: int("strategyId").notNull(),
  accountNumber: varchar("accountNumber", { length: 20 }).notNull(),
  platform: mysqlEnum("platform", ["mt4", "mt5"]).notNull(),
  depositedAmount: int("depositedAmount").notNull(),
  depositDate: timestamp("depositDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RoboForexAccount = typeof roboForexAccounts.$inferSelect;
export type InsertRoboForexAccount = typeof roboForexAccounts.$inferInsert;

/**
 * Confirmação de email para novos usuários
 */
export const emailConfirmations = mysqlTable("emailConfirmations", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  confirmed: int("confirmed").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
});

export type EmailConfirmation = typeof emailConfirmations.$inferSelect;
export type InsertEmailConfirmation = typeof emailConfirmations.$inferInsert;