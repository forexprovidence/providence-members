# Providence Members Area - TODO

## Fase 1: Autenticação e Estrutura Base
- [x] Configurar identidade visual (cores, tipografia, componentes)
- [x] Implementar sistema de autenticação com roles (admin/user)
- [x] Criar layout base com navegação principal
- [x] Desenvolver sistema de permissões baseado em roles

## Fase 2: Dashboard Principal
- [x] Criar dashboard para usuários comuns
- [x] Exibir saldo atual das estratégias
- [x] Mostrar rentabilidade acumulada
- [x] Exibir drawdown atual
- [x] Mostrar status da estratégia (ativo/pausado)
- [x] Separar visualização: Projeto Ultimate vs Projeto Alavancado
- [x] Integrar dados de performance (mockados inicialmente)

## Fase 3: Visualização de Resultados
- [x] Criar seção de resultados ao vivo
- [x] Exibir curva de capital
- [x] Mostrar rentabilidade em percentual
- [x] Exibir drawdown máximo
- [x] Mostrar períodos positivos e negativos
- [x] Implementar atualização automática com cache

## Fase 4: Painel Administrativo
- [x] Criar interface de admin
- [ ] Gerenciar usuários (listar, criar, editar, deletar)
- [x] Formulário para inserir resultados mensais por estratégia
- [ ] Dados alimentam automaticamente contas dos usuários
- [ ] Atualizar textos e avisos do sistema
- [ ] Visualizar estatísticas de usuários

## Fase 5: Área de Conteúdo Exclusivo
- [ ] Conteúdo exclusivo será implementado em fase futura (não incluído na v1)

## Fase 6: Calculadora de Aportes e Comparação
- [x] Desenvolver calculadora de simulação
- [x] Permitir escolha de período (6 meses ou 1 ano)
- [x] Implementar lógica baseada em histórico da Providence
- [x] Exibir projeção de evolução
- [x] Comparar com CDI em gráfico visual
- [x] Código modularizado para replicação no site principal
- [ ] Implementar exportação em PDF

## Fase 7: Perfil de Usuário
- [x] Criar página de perfil
- [ ] Permitir edição de informações pessoais
- [x] Implementar preferências personalizadas
- [ ] Mostrar histórico de transações
- [ ] Gerenciar dados de contato

## Fase 8: Sistema de Notificações
- [ ] Implementar sistema de notificações (fase futura)
- [ ] Criar gatilhos para atualizações de resultados
- [ ] Adicionar alertas de risco/drawdown
- [ ] Implementar comunicados administrativos
- [ ] Criar centro de notificações para usuários

## Fase 9: Histórico e Estatísticas
- [ ] Criar visualização de histórico de resultados
- [ ] Implementar gráficos de performance
- [ ] Mostrar estatísticas agregadas
- [ ] Criar relatórios exportáveis
- [ ] Implementar filtros de período

## Fase 10: PWA e Experiência Mobile
- [x] Configurar manifest.json
- [x] Implementar service worker
- [x] Otimizar para instalação
- [x] Testar offline functionality
- [x] Otimizar responsive design

## Fase 11: Integração com Site Principal
- [ ] Preparar estrutura para link de área de membros
- [ ] Coordenar com site principal
- [ ] Testar fluxo de redirecionamento
- [ ] Garantir coerência visual

## Fase 12: Testes e Qualidade
- [x] Escrever testes unitários (vitest)
- [x] Testar fluxos de autenticação
- [x] Testar permissões por role
- [ ] Testar responsividade mobile
- [ ] Testar PWA em diferentes dispositivos
- [ ] Validar performance

## Fase 13: Deploy e Entrega
- [ ] Preparar ambiente de produção
- [ ] Criar checkpoint final
- [ ] Documentar arquitetura
- [ ] Entregar ao usuário


## Correções v2 (Feedback do Usuário)

### Dashboard
- [x] Corrigir comissão para 20% (ambas estratégias)
- [x] Corrigir depósito mínimo para $200

### Resultados
- [x] Ajustar datas para 2026 (não 2024-2025)

### Calculadora
- [x] Renomear "Saldo Providence" → "Saldo com [Nome da Estratégia]"
- [x] Renomear "Saldo CDI" → "Saldo com CDI"
- [x] Renomear "Vantagem Providence" → "Diferença com [Estratégia]"
- [x] Implementar +/- dinâmico na diferença

### Admin - Resultados Mensais
- [x] Melhorar seletor de mês/ano (mais claro e funcional)
- [x] Calcular automaticamente Lucro/Prejuízo baseado em Saldo Final - Inicial
- [x] Calcular automaticamente Rentabilidade (%)
- [x] Deixar claro se campos são em % ou $
- [x] Adicionar tabela com histórico de dados preenchidos
- [x] Permitir editar registros antigos
- [x] Permitir deletar registros antigos

### Admin - Configurações
- [x] Adicionar seção de Gerenciamento de Usuários

### Identidade Visual
- [x] Usar tom de dourado correto (código hex a confirmar)
- [x] Remover tom laranja excessivo

### Perfil
- [x] Remover toggle de tema escuro

### Home (sem autenticação)
- [x] Mudar "Acessar Área de Membros" para "Fazer Login"
- [x] Adicionar "Ainda não é membro? Cadastre-se"
- [ ] Adicionar campo obrigatório: Número da Conta RoboForex (apenas números)
- [x] Remover gradiente de segurança
- [x] Corrigir depósito mínimo e comissão na página


## Correções v3 (Novo Feedback)

### Identidade Visual
- [ ] Verificar e corrigir tom laranja (deve ser #D4AF37)

### Dashboard
- [ ] Mudar mensagem para "Você ainda não possui uma conta nesta estratégia"
- [ ] Adicionar formulário para cadastrar conta (Número, Plataforma MT4/MT5, Valor depositado)
- [ ] Implementar rota tRPC para criar conta de usuário

### Resultados
- [ ] Alterar nome da linha "Providence" para nome da estratégia selecionada
- [ ] Manter "CDI" como está

### Home (Área de Membros)
- [ ] Corrigir texto do dashboard: "cadastre e visualize os dados das suas estrategias para melhor visualização"

### Admin - Gerenciamento de Usuários
- [ ] Implementar tabela com lista de usuários
- [ ] Adicionar colunas: Nome, Email, Role, Data de Criação, Ações (Editar/Deletar)
- [ ] Implementar rotas tRPC para listar, editar e deletar usuários
- [ ] Adicionar filtros e busca

### Admin - Cadastro de Usuários
- [ ] Criar aba separada para cadastro de usuários
- [ ] Adicionar formulário com: Email, Nome, Senha
- [ ] Implementar confirmação de email
- [ ] Criar rota tRPC para cadastro com validação

### Página de Cadastro (Pública)
- [ ] Criar página de cadastro pública (/signup)
- [ ] Adicionar link na Home "Ainda não é membro? Cadastre-se"
- [ ] Formulário com: Email, Nome, Senha, Confirmar Senha, Número RoboForex
- [ ] Validação de email único
- [ ] Implementar confirmação de email
- [ ] Redirecionar para login após confirmação

### Usuário Teste
- [ ] Criar usuário teste via Admin para validar funcionalidades


## Correções v4 (Feedback Crítico)

### Dashboard
- [ ] Permitir múltiplas contas por estratégia
- [ ] Adicionar botão para editar conta existente
- [ ] Adicionar botão para deletar conta existente
- [ ] Calcular lucro automaticamente baseado em resultados mensais
- [ ] Mostrar data de depósito e plataforma após cadastro
- [ ] Adicionar aviso: "Valores aproximados, podem variar por datas de depósito e Ratio"

### Calculadora
- [ ] Replicar melhoria de legenda dinâmica (nome da estratégia ao invés de "Providence")

### Admin - Gerenciamento de Usuários
- [ ] Restaurar exibição de estatísticas (Total, Comuns, Admins)
- [ ] Implementar listagem real de usuários

### Cadastro e Autenticação
- [ ] Vincular cadastro público com OAuth (mesmo email = mesmo usuário)
- [ ] Confirmar email no próprio site (não via email)
- [ ] Redirecionar para dashboard após confirmação
- [ ] Permitir login com conta cadastrada via OAuth
- [ ] Corrigir erro 404 no login

### UX
- [ ] Mover botão "Sair" para dentro do Perfil
- [ ] Manter dados de conta visíveis após cadastro
