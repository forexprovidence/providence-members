import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { strategies, monthlyResults, cdiData } from "./drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;

async function seed() {
  if (!DATABASE_URL) {
    throw new Error("DATABASE_URL not set");
  }

  console.log("🌱 Iniciando seed do banco de dados...");

  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  try {
    // Limpar dados existentes
    console.log("🗑️ Limpando dados existentes...");
    await connection.execute("DELETE FROM monthlyResults");
    await connection.execute("DELETE FROM cdiData");
    await connection.execute("DELETE FROM strategies");

    // Inserir estratégias
    console.log("📊 Inserindo estratégias...");
    await db.insert(strategies).values([
      {
        name: "Projeto Ultimate",
        description: "Estratégia conservadora focada em rentabilidade consistente e baixo risco",
        riskLevel: "conservative",
        minimumDeposit: 1000,
        commissionPercentage: 20,
        isActive: true,
      },
      {
        name: "Projeto Alavancado",
        description: "Estratégia agressiva com potencial de retornos maiores e risco moderado",
        riskLevel: "aggressive",
        minimumDeposit: 2000,
        commissionPercentage: 25,
        isActive: true,
      },
    ]);

    // Inserir resultados mensais mockados (últimos 12 meses)
    console.log("📈 Inserindo resultados mensais...");
    const now = new Date();
    const monthlyData = [
      { month: "2024-02", ultimate: 1.5, alavancado: 3.2 },
      { month: "2024-03", ultimate: 2.1, alavancado: 2.8 },
      { month: "2024-04", ultimate: 1.8, alavancado: 4.1 },
      { month: "2024-05", ultimate: 2.3, alavancado: 3.5 },
      { month: "2024-06", ultimate: 1.9, alavancado: 2.9 },
      { month: "2024-07", ultimate: 2.5, alavancado: 4.2 },
      { month: "2024-08", ultimate: 2.0, alavancado: 3.1 },
      { month: "2024-09", ultimate: 2.2, alavancado: 3.8 },
      { month: "2024-10", ultimate: 1.7, alavancado: 2.6 },
      { month: "2024-11", ultimate: 2.4, alavancado: 4.0 },
      { month: "2024-12", ultimate: 2.6, alavancado: 3.9 },
      { month: "2025-01", ultimate: 2.1, alavancado: 3.4 },
    ];

    for (const data of monthlyData) {
      // Ultimate
      await db.insert(monthlyResults).values({
        strategyId: 1,
        month: data.month,
        initialBalance: 10000,
        finalBalance: Math.round(10000 * (1 + data.ultimate / 100)),
        profitLoss: Math.round(10000 * (data.ultimate / 100)),
        profitPercentage: Math.round(data.ultimate * 100),
        maxDrawdown: Math.round(Math.random() * 200 + 50),
      });

      // Alavancado
      await db.insert(monthlyResults).values({
        strategyId: 2,
        month: data.month,
        initialBalance: 10000,
        finalBalance: Math.round(10000 * (1 + data.alavancado / 100)),
        profitLoss: Math.round(10000 * (data.alavancado / 100)),
        profitPercentage: Math.round(data.alavancado * 100),
        maxDrawdown: Math.round(Math.random() * 300 + 100),
      });
    }

    // Inserir dados do CDI
    console.log("💰 Inserindo dados do CDI...");
    const cdiMonthlyData = [
      { month: "2024-02", monthlyRate: 45, accumulatedRate: 450 },
      { month: "2024-03", monthlyRate: 44, accumulatedRate: 894 },
      { month: "2024-04", monthlyRate: 43, accumulatedRate: 1337 },
      { month: "2024-05", monthlyRate: 42, accumulatedRate: 1779 },
      { month: "2024-06", monthlyRate: 41, accumulatedRate: 2220 },
      { month: "2024-07", monthlyRate: 40, accumulatedRate: 2660 },
      { month: "2024-08", monthlyRate: 39, accumulatedRate: 3099 },
      { month: "2024-09", monthlyRate: 38, accumulatedRate: 3537 },
      { month: "2024-10", monthlyRate: 37, accumulatedRate: 3974 },
      { month: "2024-11", monthlyRate: 36, accumulatedRate: 4410 },
      { month: "2024-12", monthlyRate: 35, accumulatedRate: 4845 },
      { month: "2025-01", monthlyRate: 34, accumulatedRate: 5279 },
    ];

    for (const data of cdiMonthlyData) {
      await db.insert(cdiData).values({
        month: data.month,
        monthlyRate: data.monthlyRate,
        accumulatedRate: data.accumulatedRate,
      });
    }

    console.log("✅ Seed concluído com sucesso!");
  } catch (error) {
    console.error("❌ Erro durante seed:", error);
    throw error;
  } finally {
    await connection.end();
  }
}

seed().catch(console.error);
