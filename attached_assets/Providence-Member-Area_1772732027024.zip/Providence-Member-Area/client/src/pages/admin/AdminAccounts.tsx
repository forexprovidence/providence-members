import * as React from "react";
import { AppTopNav } from "@/components/AppTopNav";
import { PageShell } from "@/components/PageShell";
import { DashboardLayout } from "@/components/DashboardLayout";
import { SectionCard } from "@/components/SectionCard";
import { GradientButton } from "@/components/GradientButton";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useAccounts, useCreateAccount, useDeleteAccount, useUpdateAccount } from "@/hooks/use-accounts";
import { useStrategies } from "@/hooks/use-strategies";
import { useAdminUsers } from "@/hooks/use-users";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function AdminAccounts() {
  const { user } = useAuth();
  const isAdmin = Boolean((user as any)?.role === "admin" || (user as any)?.isAdmin);

  const { toast } = useToast();
  const [search, setSearch] = React.useState("");
  const q = useAccounts({ search });

  const strategies = useStrategies();
  const users = useAdminUsers();

  const create = useCreateAccount();
  const update = useUpdateAccount();
  const del = useDeleteAccount();

  const [open, setOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<any | null>(null);

  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [deleteId, setDeleteId] = React.useState<number | null>(null);

  return (
    <PageShell>
      <AppTopNav />
      <DashboardLayout
        title="Admin · Accounts"
        subtitle="Accounts link users to strategies."
        right={
          <div className="flex items-center gap-2">
            <div className="relative hidden sm:block">
              <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search…"
                className="h-11 w-[280px] rounded-2xl bg-white/5 pl-11 ring-1 ring-white/10 focus:ring-4 focus:ring-primary/15"
                data-testid="admin-accounts-search"
              />
            </div>
            <GradientButton
              onClick={() => {
                setEditing(null);
                setOpen(true);
              }}
              data-testid="admin-accounts-create"
            >
              <Plus className="h-4 w-4" />
              New
            </GradientButton>
          </div>
        }
      >
        {!isAdmin ? (
          <SectionCard title="Access denied" description="Admin permissions required." data-testid="admin-accounts-denied">
            <div className="rounded-3xl bg-destructive/10 ring-1 ring-destructive/25 p-5">
              <div className="text-sm font-semibold">You do not have admin access.</div>
            </div>
          </SectionCard>
        ) : (
          <SectionCard title="Accounts" description="Create and link accounts." data-testid="admin-accounts-card">
            {q.isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-16 rounded-3xl bg-white/5 ring-1 ring-white/10 animate-pulse" />
                ))}
              </div>
            ) : q.error ? (
              <div className="rounded-3xl bg-destructive/10 ring-1 ring-destructive/25 p-5">
                <div className="text-sm font-semibold">Couldn’t load accounts</div>
                <div className="mt-1 text-sm text-muted-foreground">{(q.error as any)?.message}</div>
              </div>
            ) : (q.data as any[])?.length ? (
              <div className="space-y-3">
                {(q.data as any[]).map((a) => (
                  <div
                    key={a.id}
                    className="flex flex-col gap-3 rounded-3xl bg-white/5 ring-1 ring-white/10 p-4 shadow-lg shadow-black/35 hover:bg-white/7 transition-colors sm:flex-row sm:items-center sm:justify-between"
                    data-testid={`admin-account-row-${a.id}`}
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-semibold truncate">{a.name ?? `Account #${a.id}`}</div>
                      <div className="mt-1 text-xs text-muted-foreground truncate">
                        User: {a.userEmail ?? a.userId ?? "—"} · Strategy: {a.strategyName ?? a.strategyId ?? "—"}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <GradientButton
                        variant="secondary"
                        className="px-4 py-2.5"
                        onClick={() => {
                          setEditing(a);
                          setOpen(true);
                        }}
                        data-testid={`admin-account-edit-${a.id}`}
                      >
                        <Pencil className="h-4 w-4" /> Edit
                      </GradientButton>
                      <GradientButton
                        variant="danger"
                        className="px-4 py-2.5"
                        onClick={() => {
                          setDeleteId(a.id);
                          setConfirmOpen(true);
                        }}
                        data-testid={`admin-account-delete-${a.id}`}
                      >
                        <Trash2 className="h-4 w-4" /> Delete
                      </GradientButton>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="rounded-3xl bg-white/5 ring-1 ring-white/10 p-7 text-center">
                <div className="text-sm font-semibold">No accounts</div>
                <div className="mt-1 text-sm text-muted-foreground">Create the first account.</div>
              </div>
            )}
          </SectionCard>
        )}

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="max-w-xl bg-popover text-popover-foreground border border-white/10 rounded-3xl shadow-lift">
            <DialogHeader>
              <DialogTitle data-testid="admin-account-dialog-title">
                {editing ? "Edit account" : "New account"}
              </DialogTitle>
            </DialogHeader>

            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);

                const payload: any = {
                  name: String(fd.get("name") ?? ""),
                  userId: String(fd.get("userId") ?? ""),
                  strategyId: Number(fd.get("strategyId") ?? 0),
                  status: String(fd.get("status") ?? "active"),
                };

                const action = editing
                  ? update.mutateAsync({ id: editing.id, ...payload })
                  : create.mutateAsync(payload);

                action
                  .then(() => {
                    toast({ title: editing ? "Account updated" : "Account created" });
                    setOpen(false);
                  })
                  .catch((err: any) => {
                    toast({
                      title: "Save failed",
                      description: err?.message ?? "Please try again.",
                      variant: "destructive",
                    });
                  });
              }}
              data-testid="admin-account-form"
            >
              <div>
                <label className="text-sm font-semibold">Name</label>
                <Input
                  name="name"
                  defaultValue={editing?.name ?? ""}
                  className="mt-2 h-11 rounded-2xl bg-background/40 ring-1 ring-white/10 focus:ring-4 focus:ring-primary/15"
                  data-testid="admin-account-name"
                  required
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="text-sm font-semibold">User</label>
                  <select
                    name="userId"
                    defaultValue={editing?.userId ?? ""}
                    className="mt-2 h-11 w-full rounded-2xl bg-white/5 px-4 text-sm font-semibold ring-1 ring-white/10 focus:outline-none focus:ring-4 focus:ring-primary/15"
                    data-testid="admin-account-userId"
                    required
                  >
                    <option value="" disabled>
                      Select user…
                    </option>
                    {(users.data as any[])?.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.email ?? u.username ?? u.id}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-sm font-semibold">Strategy</label>
                  <select
                    name="strategyId"
                    defaultValue={editing?.strategyId ?? ""}
                    className="mt-2 h-11 w-full rounded-2xl bg-white/5 px-4 text-sm font-semibold ring-1 ring-white/10 focus:outline-none focus:ring-4 focus:ring-primary/15"
                    data-testid="admin-account-strategyId"
                    required
                  >
                    <option value="" disabled>
                      Select strategy…
                    </option>
                    {(strategies.data as any[])?.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name ?? `Strategy #${s.id}`}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-sm font-semibold">Status</label>
                  <Input
                    name="status"
                    defaultValue={editing?.status ?? "active"}
                    className="mt-2 h-11 rounded-2xl bg-background/40 ring-1 ring-white/10 focus:ring-4 focus:ring-primary/15"
                    data-testid="admin-account-status"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-3 sm:flex-row sm:justify-end">
                <GradientButton
                  variant="secondary"
                  type="button"
                  onClick={() => setOpen(false)}
                  data-testid="admin-account-cancel"
                >
                  Cancel
                </GradientButton>
                <GradientButton
                  type="submit"
                  isLoading={create.isPending || update.isPending}
                  data-testid="admin-account-save"
                >
                  Save
                </GradientButton>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        <ConfirmDialog
          open={confirmOpen}
          onOpenChange={setConfirmOpen}
          title="Delete account?"
          description="This cannot be undone."
          confirmText="Delete"
          onConfirm={() => {
            if (deleteId == null) return;
            del.mutate(deleteId, {
              onSuccess: () => {
                toast({ title: "Account deleted" });
                setConfirmOpen(false);
              },
              onError: (err: any) => {
                toast({
                  title: "Delete failed",
                  description: err?.message ?? "Please try again.",
                  variant: "destructive",
                });
              },
            });
          }}
          isPending={del.isPending}
          data-testid="admin-account-delete-confirm"
        />
      </DashboardLayout>
    </PageShell>
  );
}
