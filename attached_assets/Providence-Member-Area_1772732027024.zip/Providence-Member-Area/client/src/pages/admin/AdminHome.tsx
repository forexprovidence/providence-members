import * as React from "react";
import { AppTopNav } from "@/components/AppTopNav";
import { PageShell } from "@/components/PageShell";
import { DashboardLayout } from "@/components/DashboardLayout";
import { SectionCard } from "@/components/SectionCard";
import { Link } from "wouter";
import { ArrowUpRight, ShieldCheck, Users, LineChart, Database, Wallet } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

function AdminTile({
  href,
  title,
  description,
  icon,
  tone = "primary",
  testId,
}: {
  href: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  tone?: "primary" | "accent";
  testId: string;
}) {
  const toneCls =
    tone === "accent"
      ? "from-accent/18 to-transparent ring-accent/25 hover:shadow-accent/12"
      : "from-primary/18 to-transparent ring-primary/25 hover:shadow-primary/12";

  return (
    <Link
      href={href}
      className={`group rounded-3xl bg-gradient-to-br ${toneCls} ring-1 p-5 shadow-lg shadow-black/35 hover:shadow-xl hover:shadow-black/50 transition-all duration-300`}
      data-testid={testId}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-sm font-semibold">{title}</div>
          <div className="mt-1 text-xs text-muted-foreground">{description}</div>
        </div>
        <div className="h-10 w-10 rounded-2xl bg-white/6 ring-1 ring-white/10 grid place-items-center">
          {icon}
        </div>
      </div>
      <div className="mt-4 inline-flex items-center gap-2 text-xs font-semibold text-foreground/90">
        Open <ArrowUpRight className="h-3.5 w-3.5 opacity-70 group-hover:opacity-100 transition-opacity" />
      </div>
    </Link>
  );
}

export default function AdminHome() {
  const { user } = useAuth();
  const isAdmin = Boolean((user as any)?.role === "admin" || (user as any)?.isAdmin);

  return (
    <PageShell>
      <AppTopNav />
      <DashboardLayout
        title={
          <span className="inline-flex items-center gap-3">
            <ShieldCheck className="h-7 w-7 text-accent" />
            Admin Panel
          </span>
        }
        subtitle="Full CRUD across users, strategies, strategy history, accounts, and financial records."
      >
        {!isAdmin ? (
          <SectionCard title="Access denied" description="Admin permissions required." data-testid="admin-denied">
            <div className="rounded-3xl bg-destructive/10 ring-1 ring-destructive/25 p-5">
              <div className="text-sm font-semibold">You do not have admin access.</div>
              <div className="mt-1 text-sm text-muted-foreground">
                If you believe this is a mistake, contact Providence Forex support.
              </div>
            </div>
          </SectionCard>
        ) : (
          <>
            <SectionCard
              title="Quick actions"
              description="Navigate to any dataset. All changes should reflect immediately in member dashboards."
              data-testid="admin-quick-actions"
            >
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <AdminTile
                  href="/admin/users"
                  title="Users"
                  description="View, edit, confirm, and reset passwords."
                  icon={<Users className="h-5 w-5 text-primary" />}
                  testId="admin-tile-users"
                />
                <AdminTile
                  href="/admin/strategies"
                  title="Strategies"
                  description="Create, edit, delete strategies."
                  icon={<LineChart className="h-5 w-5 text-primary" />}
                  testId="admin-tile-strategies"
                />
                <AdminTile
                  href="/admin/strategy-history"
                  title="Strategy History"
                  description="Manage performance datasets."
                  icon={<Database className="h-5 w-5 text-accent" />}
                  tone="accent"
                  testId="admin-tile-history"
                />
                <AdminTile
                  href="/admin/accounts"
                  title="Accounts"
                  description="Link users to strategies."
                  icon={<Wallet className="h-5 w-5 text-accent" />}
                  tone="accent"
                  testId="admin-tile-accounts"
                />
                <AdminTile
                  href="/admin/financial-records"
                  title="Financial Records"
                  description="Edit all financial histories."
                  icon={<Database className="h-5 w-5 text-primary" />}
                  testId="admin-tile-financial"
                />
              </div>
            </SectionCard>

            <SectionCard title="Notes" description="Operational guidance." data-testid="admin-notes">
              <div className="space-y-3 text-sm text-muted-foreground">
                <p>
                  Admin routes should be protected server-side. Frontend also hides admin navigation when not permitted.
                </p>
                <p>
                  Use full CRUD dialogs to ensure every action is wired to mutations and query invalidation.
                </p>
              </div>
            </SectionCard>
          </>
        )}
      </DashboardLayout>
    </PageShell>
  );
}
