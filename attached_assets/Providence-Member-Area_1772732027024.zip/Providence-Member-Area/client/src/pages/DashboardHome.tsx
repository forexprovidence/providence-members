import * as React from "react";
import { AppTopNav } from "@/components/AppTopNav";
import { PageShell } from "@/components/PageShell";
import { DashboardLayout } from "@/components/DashboardLayout";
import { SectionCard } from "@/components/SectionCard";
import { useDashboardOverview } from "@/hooks/use-dashboard";
import { useAuth } from "@/hooks/use-auth";
import { ArrowUpRight, BarChart3, DollarSign, TrendingDown, TrendingUp } from "lucide-react";
import { GradientButton } from "@/components/GradientButton";
import { Link } from "wouter";

function StatPill({
  label,
  value,
  icon,
  tone = "primary",
  "data-testid": dataTestId,
}: {
  label: string;
  value: React.ReactNode;
  icon: React.ReactNode;
  tone?: "primary" | "accent" | "muted" | "danger";
  "data-testid"?: string;
}) {
  const toneStyles =
    tone === "primary"
      ? "from-primary/18 to-transparent ring-primary/20"
      : tone === "accent"
        ? "from-accent/16 to-transparent ring-accent/20"
        : tone === "danger"
          ? "from-destructive/16 to-transparent ring-destructive/25"
          : "from-white/8 to-transparent ring-white/10";

  return (
    <div
      className={`rounded-3xl bg-gradient-to-br ${toneStyles} ring-1 p-5 shadow-lg shadow-black/40 hover:shadow-xl hover:shadow-black/50 transition-all duration-300`}
      data-testid={dataTestId}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="h-9 w-9 rounded-2xl bg-white/6 ring-1 ring-white/10 grid place-items-center">
          {icon}
        </div>
      </div>
      <div className="mt-3 text-2xl font-semibold tracking-tight">{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">Updated live from your linked data.</div>
    </div>
  );
}

export default function DashboardHome() {
  const { user } = useAuth();
  const overview = useDashboardOverview();

  const displayName = user?.email ?? "Member";

  return (
    <PageShell>
      <AppTopNav />

      <DashboardLayout
        title={
          <span>
            Welcome back,{" "}
            <span className="bg-gradient-to-r from-primary via-primary/70 to-accent bg-clip-text text-transparent">
              {displayName}
            </span>
          </span>
        }
        subtitle="Your performance overview is calculated from the strategies linked to your accounts."
        right={
          <div className="flex items-center gap-2">
            <Link
              href="/accounts"
              className="inline-flex items-center gap-2 rounded-2xl bg-white/5 px-4 py-2.5 text-sm font-semibold ring-1 ring-white/10 hover:bg-white/8 transition-colors"
              data-testid="go-accounts"
            >
              Manage Accounts <ArrowUpRight className="h-4 w-4" />
            </Link>
            <GradientButton
              variant="secondary"
              onClick={() => window.location.href = "/admin"}
              data-testid="quick-admin"
              className="hidden md:inline-flex"
            >
              Admin
              <ArrowUpRight className="h-4 w-4" />
            </GradientButton>
          </div>
        }
      >
        <SectionCard
          title="Snapshot"
          description="Net result is computed from profit and loss derived from your strategy history."
          data-testid="dashboard-snapshot"
        >
          {overview.isLoading ? (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="h-[120px] rounded-3xl bg-white/5 ring-1 ring-white/10 animate-pulse"
                  data-testid={`snapshot-skeleton-${i}`}
                />
              ))}
            </div>
          ) : overview.error ? (
            <div className="rounded-3xl bg-destructive/10 ring-1 ring-destructive/25 p-5">
              <div className="text-sm font-semibold">Couldn’t load overview</div>
              <div className="mt-1 text-sm text-muted-foreground">
                {(overview.error as any)?.message ?? "Try again later."}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <StatPill
                label="Profit"
                value={(overview.data as any)?.profit ?? "—"}
                icon={<TrendingUp className="h-4 w-4 text-primary" />}
                tone="primary"
                data-testid="stat-profit"
              />
              <StatPill
                label="Loss"
                value={(overview.data as any)?.loss ?? "—"}
                icon={<TrendingDown className="h-4 w-4 text-destructive" />}
                tone="danger"
                data-testid="stat-loss"
              />
              <StatPill
                label="Net"
                value={(overview.data as any)?.net ?? "—"}
                icon={<DollarSign className="h-4 w-4 text-accent" />}
                tone="accent"
                data-testid="stat-net"
              />
            </div>
          )}
        </SectionCard>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <SectionCard
            title="Accounts"
            description="Your accounts are the bridge between member identity and strategy performance."
            data-testid="dashboard-accounts-card"
            right={
              <Link
                href="/accounts"
                className="inline-flex items-center gap-2 rounded-2xl bg-white/5 px-4 py-2 text-sm font-semibold ring-1 ring-white/10 hover:bg-white/8 transition-colors"
                data-testid="dashboard-accounts-link"
              >
                Open <ArrowUpRight className="h-4 w-4" />
              </Link>
            }
          >
            <div className="rounded-3xl bg-white/5 ring-1 ring-white/10 p-5">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-2xl bg-primary/12 ring-1 ring-primary/20 grid place-items-center">
                  <BarChart3 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-semibold">Keep it consistent</div>
                  <div className="text-xs text-muted-foreground">
                    Linking strategies ensures profit/loss stays automatic.
                  </div>
                </div>
              </div>
              <div className="mt-4 text-xs text-muted-foreground">
                Admin changes reflect immediately across member dashboards via cache invalidation.
              </div>
            </div>
          </SectionCard>

          <SectionCard
            title="Strategies"
            description="Explore the performance dataset powering your calculations."
            data-testid="dashboard-strategies-card"
            right={
              <Link
                href="/strategies"
                className="inline-flex items-center gap-2 rounded-2xl bg-white/5 px-4 py-2 text-sm font-semibold ring-1 ring-white/10 hover:bg-white/8 transition-colors"
                data-testid="dashboard-strategies-link"
              >
                Open <ArrowUpRight className="h-4 w-4" />
              </Link>
            }
          >
            <div className="rounded-3xl bg-gradient-to-br from-accent/10 via-white/4 to-primary/10 ring-1 ring-white/10 p-5">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-2xl bg-accent/12 ring-1 ring-accent/20 grid place-items-center">
                  <BarChart3 className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <div className="text-sm font-semibold">History-first</div>
                  <div className="text-xs text-muted-foreground">
                    Strategy datasets drive all financial outcomes.
                  </div>
                </div>
              </div>
              <div className="mt-4 text-xs text-muted-foreground">
                Admin can CRUD strategies and history—member pages remain read-optimized.
              </div>
            </div>
          </SectionCard>
        </div>
      </DashboardLayout>
    </PageShell>
  );
}
